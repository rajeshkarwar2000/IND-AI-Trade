import 'dart:convert';
import 'dart:io';
import 'package:shared_preferences/shared_preferences.dart';

const _defHol={'2026-01-15':'Maharashtra civic elections','2026-01-26':'Republic Day','2026-03-03':'Holi','2026-03-26':'Shri Ram Navami','2026-03-31':'Shri Mahavir Jayanti',
  '2026-04-03':'Good Friday','2026-04-14':'Dr. Ambedkar Jayanti','2026-05-01':'Maharashtra Day','2026-05-28':'Bakri Id','2026-06-26':'Muharram','2026-09-14':'Ganesh Chaturthi',
  '2026-10-02':'Gandhi Jayanti','2026-10-20':'Dussehra','2026-11-10':'Diwali Balipratipada','2026-11-24':'Guru Nanak Jayanti','2026-12-25':'Christmas'};
class Cal{
  static Map<String,String> hol=Map.of(_defHol);
  static Map<String,String> special={'2026-11-08':'Muhurat trading (Sunday evening special session)'};
  static Map<String,int> weekly={'NIFTY':2,'SENSEX':4};
  static Map<String,int> monthly={'NIFTY':2,'BANKNIFTY':2,'FINNIFTY':2,'SENSEX':4};
  static String updated='Built-in list (checked 10 Nov 2026)',url='';
  static void reset(){hol=Map.of(_defHol);special={'2026-11-08':'Muhurat trading (Sunday evening special session)'};weekly={'NIFTY':2,'SENSEX':4};
    monthly={'NIFTY':2,'BANKNIFTY':2,'FINNIFTY':2,'SENSEX':4};updated='Built-in list (checked 10 Nov 2026)';}
  static String years()=>(hol.keys.map((k)=>k.substring(0,4)).toSet().toList()..sort()).join(', ');
}
const _wd=['Mon','Tue','Wed','Thu','Fri','Sat','Sun'];
const _mo=['JAN','FEB','MAR','APR','MAY','JUN','JUL','AUG','SEP','OCT','NOV','DEC'];
String wdName(int w)=>_wd[w-1];
String dkey(DateTime d)=>'${d.year}-${d.month.toString().padLeft(2,'0')}-${d.day.toString().padLeft(2,'0')}';
DateTime dOnly(DateTime d)=>DateTime(d.year,d.month,d.day);
DateTime _addD(DateTime d,int n)=>DateTime(d.year,d.month,d.day+n);
String fdate(DateTime d)=>'${_wd[d.weekday-1]} ${d.day.toString().padLeft(2,'0')} ${_mo[d.month-1]} ${d.year}';
bool isTD(DateTime d)=>d.weekday<=5&&!Cal.hol.containsKey(dkey(d));
DateTime prevTD(DateTime d){var x=dOnly(d);while(!isTD(x)){x=_addD(x,-1);}return x;}
DateTime nextTD(DateTime d){var x=_addD(dOnly(d),1);while(!isTD(x)){x=_addD(x,1);}return x;}
List<DateTime> sessions(DateTime now,int n){final o=<DateTime>[];var d=dOnly(now);
  if(!(isTD(d)&&now.hour*60+now.minute<930))d=nextTD(d);
  o.add(d);while(o.length<n){d=nextTD(d);o.add(d);}return o;}
String status(DateTime now){final d=dOnly(now),k=dkey(d),m=now.hour*60+now.minute;
  if(Cal.special.containsKey(k))return 'SPECIAL SESSION today: ${Cal.special[k]}. Check the NSE circular for timings';
  if(d.weekday>5)return 'CLOSED - weekend';
  if(Cal.hol.containsKey(k))return 'CLOSED - holiday: ${Cal.hol[k]}';
  if(m<555)return 'Not open yet (opens 9:15 AM)';
  if(m<=930)return 'OPEN now (9:15 AM to 3:30 PM)';
  return 'CLOSED - today\'s session is over';}
class Exp{final DateTime date;final String tag;Exp(this.date,this.tag);}
DateTime _lastWd(int y,int m,int wd){var d=DateTime(y,m+1,0);while(d.weekday!=wd){d=_addD(d,-1);}return d;}
List<Exp> expiries(String ix,DateTime now,{int weeks=4}){
  final today=dOnly(now),over=now.hour*60+now.minute>=930;
  bool ok(DateTime d)=>d.isAfter(today)||(d==today&&!over);
  final tags=<DateTime,String>{};final wd=Cal.weekly[ix],md=Cal.monthly[ix];
  if(wd!=null){var d=today;while(d.weekday!=wd){d=_addD(d,1);}
    for(var i=0;i<weeks+3;i++){final raw=_addD(d,7*i),sh=prevTD(raw);
      if(ok(sh)&&!tags.containsKey(sh)&&tags.length<weeks){tags[sh]=sh==raw?'WEEKLY':'WEEKLY, moved from ${fdate(raw)} holiday';}}}
  if(md!=null){var c=0;for(var k=0;k<6&&c<3;k++){final mm=DateTime(today.year,today.month+k,1);final raw=_lastWd(mm.year,mm.month,md),sh=prevTD(raw);
    if(!ok(sh))continue;c++;final base=sh==raw?'':', moved from ${fdate(raw)} holiday';
    tags[sh]=tags.containsKey(sh)?'WEEKLY + MONTHLY$base':'MONTHLY$base';}}
  return (tags.entries.map((e)=>Exp(e.key,e.value)).toList()..sort((a,b)=>a.date.compareTo(b.date)));}
DateTime nearestExpiry(List<Exp> c,DateTime? t){if(t==null)return c.first.date;var b=c.first.date;var bd=b.difference(t).inDays.abs();
  for(final e in c){final dd=e.date.difference(t).inDays.abs();if(dd<bd){b=e.date;bd=dd;}}return b;}
String calendarFacts(String ix,DateTime now){
  final today=dOnly(now),b=StringBuffer();
  final hm='${now.hour.toString().padLeft(2,'0')}:${now.minute.toString().padLeft(2,'0')} IST';
  b.writeln('TODAY: ${fdate(now)}, $hm. MARKET STATUS: ${status(now)}.');
  b.writeln('NEXT 3 TRADING SESSIONS: ${sessions(now,3).map(fdate).join(', ')}.');
  for(final x in (ix=='ANY'?['NIFTY','BANKNIFTY','FINNIFTY','SENSEX']:[ix])){
    final e=expiries(x,now);b.writeln('$x VALID EXPIRIES: ${e.isEmpty?'none (check circulars)':e.map((v)=>'${fdate(v.date)} [${v.tag}]').join('; ')}.');}
  final up=Cal.hol.entries.where((e){final d=DateTime.tryParse(e.key);return d!=null&&!d.isBefore(today)&&d.isBefore(_addD(today,46));}).map((e)=>'${fdate(DateTime.parse(e.key))}: ${e.value}');
  b.writeln('TRADING HOLIDAYS in next 45 days: ${up.isEmpty?'none':up.join('; ')}.');
  b.writeln('RULES: weekly expiry = ${Cal.weekly.entries.map((e)=>'${e.key} ${wdName(e.value)}').join(', ')}; monthly expiry = last weekday of month: ${Cal.monthly.entries.map((e)=>'${e.key} ${wdName(e.value)}').join(', ')}; an expiry on a holiday moves to the previous trading day.');
  if(!Cal.hol.keys.any((k)=>k.startsWith('${now.year}')))b.writeln('WARNING: the app has no holiday list for ${now.year}. Verify holidays yourself from the official NSE circular.');
  return b.toString();}

bool _parse(String t,bool replace){
  try{
    final a=t.indexOf('{'),b=t.lastIndexOf('}');if(a<0||b<=a)return false;
    final m=jsonDecode(t.substring(a,b+1));if(m is! Map)return false;
    final h=m['holidays'];if(h is! Map||h.isEmpty)return false;
    final nh=<String,String>{};
    for(final e in h.entries){final d=DateTime.tryParse(e.key.toString());if(d==null)return false;nh[dkey(d)]=e.value.toString();}
    final sp=<String,String>{};final s=m['special_sessions'];
    if(s is Map){for(final e in s.entries){final d=DateTime.tryParse(e.key.toString());if(d!=null)sp[dkey(d)]=e.value.toString();}}
    Map<String,int>? rd(dynamic v){if(v is! Map)return null;final o=<String,int>{};
      for(final e in v.entries){final n=e.value is num?(e.value as num).toInt():(int.tryParse(e.value.toString())??0);if(n<1||n>5)return null;o[e.key.toString().toUpperCase()]=n;}
      return o.isEmpty?null:o;}
    final w=rd(m['weekly']),mo=rd(m['monthly']);
    Cal.hol=replace?nh:{...Cal.hol,...nh};Cal.special=replace?sp:{...Cal.special,...sp};
    if(w!=null)Cal.weekly=w;if(mo!=null)Cal.monthly=mo;
    Cal.updated='Updated ${m['updated']??'unknown date'}';return true;
  }catch(_){return false;}}
Future<void> _save()async{final p=await SharedPreferences.getInstance();
  await p.setString('sched',jsonEncode({'updated':Cal.updated.replaceFirst('Updated ',''),'holidays':Cal.hol,'special_sessions':Cal.special,'weekly':Cal.weekly,'monthly':Cal.monthly}));}
Future<bool> applySchedule(String t,{bool replace=false})async{final ok=_parse(t,replace);if(ok)await _save();return ok;}
Future<void> loadSchedule()async{final p=await SharedPreferences.getInstance();Cal.url=p.getString('schedUrl')??'';final s=p.getString('sched');if(s!=null)_parse(s,true);}
Future<void> saveUrl(String u)async{final p=await SharedPreferences.getInstance();await p.setString('schedUrl',u);}
Future<void> resetSchedule()async{final p=await SharedPreferences.getInstance();await p.remove('sched');Cal.reset();}
Future<bool> fetchSchedule(String url)async{
  try{final c=HttpClient();final rq=await c.getUrl(Uri.parse(url)).timeout(const Duration(seconds:8));final rs=await rq.close().timeout(const Duration(seconds:8));
    if(rs.statusCode!=200){c.close();return false;}final body=await rs.transform(utf8.decoder).join();c.close();return applySchedule(body,replace:true);}
  catch(_){return false;}}
