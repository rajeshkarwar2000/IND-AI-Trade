import 'dart:math';
import 'calendar.dart';
class Bar{final double o,h,l,c,v;Bar(this.o,this.h,this.l,this.c,this.v);}
class Inp{
  final String ix,style;final double vix,pcr,oi,spot,live,prev;final int dte;final bool simple;final DateTime expiry;final List<Bar> bars;
  Inp({required this.ix,required this.style,required this.vix,required this.pcr,required this.oi,required this.spot,required this.live,required this.prev,
    required this.dte,required this.simple,required this.expiry,required this.bars});
}
class Res{
  double score=0,spot=0,atr=0,rsi=0,hist=0,pb=0,vwap=0,e20=0,e50=0,iv=0,entry=0,sl=0,tgt=0,delta=0,theta=0,pUp=0,pDn=0,pFlat=0,conv=0,dipLevel=0,maxBuy=0;
  int atm=0;String bias='',action='',legs='',when='',style='',timeWin='',exitBy='',plain='';bool hasH=false;
  Map<String,double> parts={};List<List<double>> days=[];List<String> notes=[];
}
const steps={'NIFTY':50,'BANKNIFTY':100,'FINNIFTY':50,'SENSEX':100};
String fd(DateTime d){const m=['JAN','FEB','MAR','APR','MAY','JUN','JUL','AUG','SEP','OCT','NOV','DEC'];return '${d.day.toString().padLeft(2,'0')} ${m[d.month-1]}';}
DateTime tdAdd(DateTime d,int n){for(var i=0;i<n;i++){d=nextTD(d);}return d;}
List<double> emaS(List<double> x,int n){final k=2/(n+1);final o=<double>[];var e=x.first;for(final v in x){e=v*k+e*(1-k);o.add(e);}return o;}
double rsiF(List<double> c,int n){double g=0,l=0;for(var i=c.length-n;i<c.length;i++){final d=c[i]-c[i-1];if(d>0){g+=d;}else{l-=d;}}return l==0?100:100-100/(1+g/l);}
double atrF(List<Bar> b,int n){double s=0;for(var i=b.length-n;i<b.length;i++){s+=max(b[i].h-b[i].l,max((b[i].h-b[i-1].c).abs(),(b[i].l-b[i-1].c).abs()));}return s/n;}
double _cdf(double x){final t=1/(1+.2316419*x.abs());final d=.3989423*exp(-x*x/2);final p=d*t*(.3193815+t*(-.3565638+t*(1.781478+t*(-1.821256+t*1.330274))));return x>0?1-p:p;}
double bs(bool call,double s,double k,double v,double t){const r=.065;final d1=(log(s/k)+(r+v*v/2)*t)/(v*sqrt(t));final d2=d1-v*sqrt(t);
  return call?s*_cdf(d1)-k*exp(-r*t)*_cdf(d2):k*exp(-r*t)*_cdf(-d2)-s*_cdf(-d1);}
List<Bar> parseCsv(String t){final o=<Bar>[];for(final l in t.split('\n')){final p=l.split(',').map((e)=>double.tryParse(e.trim())).toList();
  if(p.length>=5){final q=p.sublist(p.length-5);if(!q.contains(null)){o.add(Bar(q[0]!,q[1]!,q[2]!,q[3]!,q[4]!));}}}return o;}

Res analyze(Inp i){
  final b=i.bars,hasH=b.length>=30,r=Res();final c=b.map((e)=>e.c).toList();
  final s=i.spot>0?i.spot:(hasH?c.last:i.prev),iv=i.vix/100;
  double e20=s,e50=s,h=0,pb=.5,vw=s,rs=50,at=s*iv/sqrt(252);
  bool up=i.prev>0&&s>i.prev;final p=<String,double>{};
  if(hasH){
    e20=emaS(c,20).last;e50=emaS(c,50).last;
    final a=emaS(c,12),z=emaS(c,26);final m=[for(var k=0;k<c.length;k++)a[k]-z[k]];h=m.last-emaS(m,9).last;
    final w=c.sublist(c.length-20);final mean=w.reduce((x,y)=>x+y)/20;
    final sd=sqrt(w.map((x)=>(x-mean)*(x-mean)).reduce((x,y)=>x+y)/20);pb=(s-(mean-2*sd))/(4*sd);
    double pv=0,vv=0;for(final x in b.sublist(b.length-20)){pv+=(x.h+x.l+x.c)/3*x.v;vv+=x.v;}vw=vv==0?mean:pv/vv;
    rs=rsiF(c,14);at=atrF(b,14);up=s>c[c.length-2];
    p['Market direction (EMA)']=(s>e20?10.0:-10.0)+(e20>e50?10.0:-10.0);
    p['Momentum (MACD)']=h>0?15.0:-15.0;
    p['Strength (RSI)']=rs>75?-5.0:rs>55?10.0:rs<25?5.0:rs<45?-10.0:0.0;
    p['Price vs band (Bollinger)']=((pb-.5)*20).clamp(-10.0,10.0).toDouble();
    p['Price vs average (VWAP)']=s>vw?10.0:-10.0;
    p['Last 5 days move']=((s/c[c.length-6]-1)*500).clamp(-10.0,10.0).toDouble();
  }else{
    p['Move vs yesterday']=i.prev>0?((s/i.prev-1)*400).clamp(-20.0,20.0).toDouble():0.0;
  }
  p['Put/Call ratio (PCR)']=((i.pcr-1)*50).clamp(-15.0,15.0).toDouble();
  p['Big players (OI)']=i.oi>0?(up?10.0:-10.0):(up?5.0:-5.0);
  final sc=p.values.reduce((x,y)=>x+y).clamp(-100.0,100.0).toDouble();
  var sty=i.style;if(sty=='Auto'){sty=(i.dte<=1||sc.abs()<45)?'Intraday':'Swing';}
  final swing=sty=='Swing';
  final st=steps[i.ix]??50,atm=(s/st).round()*st,T=max(i.dte,1)/365;
  double pr(bool call,int k)=>bs(call,s,k.toDouble(),iv,T);
  final bull=sc>=25,bear=sc<=-25,hi=i.vix>=16,buyOnly=i.simple||!hi,ex=fd(i.expiry);
  int? k;bool call=true;
  if(bull&&buyOnly){r.action='BUY CALL';k=atm;}
  else if(bear&&buyOnly){r.action='BUY PUT';k=atm;call=false;}
  else if(bull){r.action='SELL PUT SPREAD';r.legs='$ex: SELL ${atm-st} PE | BUY ${atm-3*st} PE';r.entry=pr(false,atm-st)-pr(false,atm-3*st);}
  else if(bear){r.action='SELL CALL SPREAD';r.legs='$ex: SELL ${atm+st} CE | BUY ${atm+3*st} CE';r.entry=pr(true,atm+st)-pr(true,atm+3*st);}
  else if(hi&&!i.simple){r.action='IRON CONDOR';r.legs='$ex: SELL ${atm+2*st} CE, BUY ${atm+4*st} CE | SELL ${atm-2*st} PE, BUY ${atm-4*st} PE';
    r.entry=pr(true,atm+2*st)-pr(true,atm+4*st)+pr(false,atm-2*st)-pr(false,atm-4*st);}
  else{r.action='NO TRADE - WAIT';r.legs='No clear chance now';}
  if(k!=null){
    final kk=k.toDouble(),dt=min(1/365,T*.5);
    r.entry=i.live>0?i.live:bs(call,s,kk,iv,T);r.sl=r.entry*(swing?0.70:0.75);r.tgt=r.entry*(swing?1.7:1.4);r.maxBuy=r.entry*1.05;
    r.delta=(bs(call,s+1,kk,iv,T)-bs(call,s-1,kk,iv,T))/2;r.theta=bs(call,s,kk,iv,T-dt)-bs(call,s,kk,iv,T);
    r.legs='${i.ix} $ex $atm ${call?'CE':'PE'}';
    final ext=call?(rs>70||pb>.95||(s-vw)/at>1.0):(rs<30||pb<.05||(vw-s)/at>1.0);
    r.dipLevel=call?s-.6*at:s+.6*at;r.when=ext?(call?'WAIT FOR A SMALL DIP':'WAIT FOR A SMALL BOUNCE'):'BUY NOW';
    if(ext){r.notes.add('Market already moved a lot. Do not chase. Buy only when the index comes ${call?'down':'up'} near ${r.dipLevel.round()}. Option price then is about Rs ${max(1.0,r.entry+r.delta*(r.dipLevel-s)).toStringAsFixed(0)}.');}
  }else if(r.entry>0){r.when='ENTER NOW';r.sl=r.entry*2;r.tgt=r.entry*.4;}
  if(r.entry>0){
    final now=DateTime.now(),td=sessions(now,1).first;
    r.timeWin=swing?'2:30-3:15 PM today, or 9:45-11:00 AM next day':'9:45-11:00 AM (after opening noise)';
    r.exitBy=swing?'${fd(tdAdd(td,2))}, by 3:00 PM':'${fd(td)}, before 3:15 PM';
    if(i.live<=0)r.notes.add('Price is an estimate. Check the real price in your broker app and type it in the "Live option price" box.');
    if(!hasH)r.notes.add('No price history added, so chart signals were skipped. Paste history for better timing.');
    if(i.vix>=18)r.notes.add('Fear meter (VIX) is high, so options are costly. Use a small quantity.');
    if(i.dte<=1)r.notes.add('Expiry is very close. Price can fall to zero fast. Use a very small quantity.');
    if(swing&&i.dte<3)r.notes.add('For 2-day holding, pick an expiry at least 3 days away.');
    r.notes.add('Risk only 1-2% of your money on one trade. Always place the stop-loss.');
  }
  r.plain=r.action=='BUY CALL'?'You earn if the market goes UP.':r.action=='BUY PUT'?'You earn if the market goes DOWN.':
    r.action.startsWith('SELL')?'Advanced: you collect fixed money if market stays on one side. Needs margin.':r.action=='IRON CONDOR'?'Advanced: you earn if market stays in a range. Needs margin.':
    'No clear chance. Staying out is also a smart trade.';
  final s1=s*iv*sqrt(1/252),s2=s*iv*sqrt(2/252),s3=s*iv*sqrt(3/252),d=sc/100*.5;
  r.days=[[s+d*s1-s1,s+d*s1,s+d*s1+s1],[s+d*s2-s2,s+d*s2,s+d*s2+s2],[s+d*s3-s3,s+d*s3,s+d*s3+s3]];
  r.pFlat=.2*(1-sc.abs()/100);final pu=1/(1+exp(-sc/25));r.pUp=pu*(1-r.pFlat);r.pDn=(1-pu)*(1-r.pFlat);
  r..score=sc..spot=s..atr=at..rsi=rs..hist=h..pb=pb..vwap=vw..e20=e20..e50=e50..iv=iv..atm=atm..parts=p..hasH=hasH
   ..style=swing?'2-Day swing':'Intraday (same day)'..bias=bull?'BULLISH (up)':bear?'BEARISH (down)':'SIDEWAYS'..conv=min(95.0,40+sc.abs()*.8);
  return r;
}
