import 'dart:math';
class Bar{final double o,h,l,c,v;Bar(this.o,this.h,this.l,this.c,this.v);}
class Inp{final String ix;final double vix,pcr,oi;final int dte;final List<Bar> bars;Inp(this.ix,this.vix,this.pcr,this.oi,this.dte,this.bars);}
class Res{
  double score=0,spot=0,atr=0,rsi=0,hist=0,pb=0,vwap=0,e20=0,e50=0,iv=0,entry=0,sl=0,tgt=0,delta=0,theta=0,pUp=0,pDn=0,pFlat=0,conv=0;
  int atm=0;String bias='',action='',legs='';
  Map<String,double> parts={};
  List<List<double>> days=[];
}
const steps={'NIFTY':50,'BANKNIFTY':100,'FINNIFTY':50,'SENSEX':100};
const base={'NIFTY':24000.0,'BANKNIFTY':52000.0,'FINNIFTY':23500.0,'SENSEX':79000.0};

List<double> emaS(List<double> x,int n){final k=2/(n+1);final o=<double>[];var e=x.first;for(final v in x){e=v*k+e*(1-k);o.add(e);}return o;}
double rsiF(List<double> c,int n){double g=0,l=0;for(var i=c.length-n;i<c.length;i++){final d=c[i]-c[i-1];if(d>0){g+=d;}else{l-=d;}}return l==0?100:100-100/(1+g/l);}
double atrF(List<Bar> b,int n){double s=0;for(var i=b.length-n;i<b.length;i++){s+=max(b[i].h-b[i].l,max((b[i].h-b[i-1].c).abs(),(b[i].l-b[i-1].c).abs()));}return s/n;}
double _cdf(double x){final t=1/(1+.2316419*x.abs());final d=.3989423*exp(-x*x/2);final p=d*t*(.3193815+t*(-.3565638+t*(1.781478+t*(-1.821256+t*1.330274))));return x>0?1-p:p;}
double bs(bool call,double s,double k,double v,double t){const r=.065;final d1=(log(s/k)+(r+v*v/2)*t)/(v*sqrt(t));final d2=d1-v*sqrt(t);
  return call?s*_cdf(d1)-k*exp(-r*t)*_cdf(d2):k*exp(-r*t)*_cdf(-d2)-s*_cdf(-d1);}

List<Bar> parseCsv(String t){final o=<Bar>[];for(final l in t.split('\n')){final p=l.split(',').map((e)=>double.tryParse(e.trim())).toList();
  if(p.length>=5){final q=p.sublist(p.length-5);if(!q.contains(null)){o.add(Bar(q[0]!,q[1]!,q[2]!,q[3]!,q[4]!));}}}return o;}
List<Bar> demo(String ix){final R=Random(7);var c=base[ix]!;final o=<Bar>[];for(var i=0;i<60;i++){final op=c;c=op*(1+.0006+(R.nextDouble()-.5)*.016);
  o.add(Bar(op,max(op,c)*(1+.003*R.nextDouble()),min(op,c)*(1-.003*R.nextDouble()),c,1e6*(.8+R.nextDouble()*.4)));}return o;}

Res analyze(Inp i){
  final b=i.bars,c=b.map((e)=>e.c).toList(),s=c.last,r=Res();
  final e20=emaS(c,20).last,e50=emaS(c,50).last;
  final a=emaS(c,12),z=emaS(c,26);final m=[for(var k=0;k<c.length;k++)a[k]-z[k]];final h=m.last-emaS(m,9).last;
  final w=c.sublist(c.length-20);final mean=w.reduce((x,y)=>x+y)/20;
  final sd=sqrt(w.map((x)=>(x-mean)*(x-mean)).reduce((x,y)=>x+y)/20);final pb=(s-(mean-2*sd))/(4*sd);
  double pv=0,vv=0;for(final x in b.sublist(b.length-20)){pv+=(x.h+x.l+x.c)/3*x.v;vv+=x.v;}final vw=vv==0?mean:pv/vv;
  final rs=rsiF(c,14),at=atrF(b,14),up=s>c[c.length-2];
  final p=<String,double>{
    'Trend EMA20/50':(s>e20?10.0:-10.0)+(e20>e50?10.0:-10.0),
    'MACD histogram':h>0?15.0:-15.0,
    'RSI regime':rs>75?-5.0:rs>55?10.0:rs<25?5.0:rs<45?-10.0:0.0,
    'Bollinger %B':((pb-.5)*20).clamp(-10.0,10.0).toDouble(),
    'VWAP (20d)':s>vw?10.0:-10.0,
    'PCR (OI)':((i.pcr-1)*50).clamp(-15.0,15.0).toDouble(),
    'Price x OI buildup':i.oi>0?(up?10.0:-10.0):(up?5.0:-5.0),
    'Momentum 5d':((s/c[c.length-6]-1)*500).clamp(-10.0,10.0).toDouble(),
  };
  final sc=p.values.reduce((x,y)=>x+y).clamp(-100.0,100.0).toDouble();
  final st=steps[i.ix]??50,atm=(s/st).round()*st,iv=i.vix/100,T=max(i.dte,1)/365;
  double pr(bool call,int k)=>bs(call,s,k.toDouble(),iv,T);
  final bull=sc>=25,bear=sc<=-25,hi=i.vix>=16;
  int? k;bool call=true;
  if(bull&&!hi){r.action='BUY CALL';r.legs='BUY $atm CE';k=atm;r.entry=pr(true,atm);r.sl=r.entry*.7;r.tgt=r.entry*1.6;}
  else if(bear&&!hi){r.action='BUY PUT';r.legs='BUY $atm PE';k=atm;call=false;r.entry=pr(false,atm);r.sl=r.entry*.7;r.tgt=r.entry*1.6;}
  else if(bull){r.action='SELL PUT SPREAD';r.legs='SELL ${atm-st} PE | BUY ${atm-3*st} PE';r.entry=pr(false,atm-st)-pr(false,atm-3*st);r.sl=r.entry*2;r.tgt=r.entry*.4;}
  else if(bear){r.action='SELL CALL SPREAD';r.legs='SELL ${atm+st} CE | BUY ${atm+3*st} CE';r.entry=pr(true,atm+st)-pr(true,atm+3*st);r.sl=r.entry*2;r.tgt=r.entry*.4;}
  else if(hi){r.action='IRON CONDOR';r.legs='SELL ${atm+2*st} CE, BUY ${atm+4*st} CE | SELL ${atm-2*st} PE, BUY ${atm-4*st} PE';
    r.entry=pr(true,atm+2*st)-pr(true,atm+4*st)+pr(false,atm-2*st)-pr(false,atm-4*st);r.sl=r.entry*2;r.tgt=r.entry*.4;}
  else{r.action='NO TRADE / WAIT';r.legs='Low IV and no directional edge';}
  if(k!=null){final kk=k.toDouble(),dt=min(1/365,T*.5);r.delta=(bs(call,s+1,kk,iv,T)-bs(call,s-1,kk,iv,T))/2;r.theta=bs(call,s,kk,iv,T-dt)-bs(call,s,kk,iv,T);}
  final s1=s*iv*sqrt(1/252),s2=s*iv*sqrt(2/252),d=sc/100*.5;
  r.days=[[s+d*s1-s1,s+d*s1,s+d*s1+s1],[s+d*s2-s2,s+d*s2,s+d*s2+s2]];
  r.pFlat=.2*(1-sc.abs()/100);final pu=1/(1+exp(-sc/25));r.pUp=pu*(1-r.pFlat);r.pDn=(1-pu)*(1-r.pFlat);
  r..score=sc..spot=s..atr=at..rsi=rs..hist=h..pb=pb..vwap=vw..e20=e20..e50=e50..iv=iv..atm=atm..parts=p
   ..bias=bull?'BULLISH':bear?'BEARISH':'NEUTRAL / RANGE'..conv=min(95.0,40+sc.abs()*.8);
  return r;
}
