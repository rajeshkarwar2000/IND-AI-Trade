import 'engine.dart';

String buildPrompt(Inp i,Res r){
  final n=DateTime.now();
  final f=(double x)=>x.toStringAsFixed(2);
  return '''You are a senior Indian derivatives (NSE/BSE F&O) strategist. Use live web search for today's data. Explain in very simple words for a beginner.
DATE/TIME: $n (IST) | INSTRUMENT: ${i.ix} INDEX OPTIONS (OPTIDX) | EXPIRY: ${fd(i.expiry)} (${i.dte} days) | STYLE: ${r.style} | USER LIVE OPTION PRICE: ${i.live>0?i.live:'not given'}
MY QUANT ENGINE: spot ${f(r.spot)}, yesterday close ${i.prev}, ATR ${f(r.atr)}, RSI ${f(r.rsi)}, EMA20 ${f(r.e20)}, EMA50 ${f(r.e50)}, VWAP ${f(r.vwap)}, India VIX ${i.vix}, PCR ${i.pcr}, FUT OI change ${i.oi}%.
Score ${r.score.round()}/100 => ${r.bias}. Proposed: ${r.action} (${r.legs}), decision ${r.when}.
CHECK: price action and support/resistance, option chain (max pain, highest CE/PE OI, IV), FII/DII flows, GIFT Nifty, global cues, India VIX trend, events in next 2 sessions, Greeks of the trade. Reject my proposal if the data does not support it.
REPLY WITH ONLY ONE JSON OBJECT. No markdown fences, no extra text before or after. Use numbers (not text) for numeric fields and exactly these keys:
{"market_view":"BULLISH or BEARISH or SIDEWAYS","confidence_pct":0,"action":"BUY CALL or BUY PUT or NO TRADE","timing":"BUY NOW or WAIT FOR DIP or WAIT FOR BOUNCE or AVOID",
"instrument":"e.g. NIFTY 09 NOV 24900 CE","strike":0,"expiry":"09 NOV","entry_price_min":0,"entry_price_max":0,"stop_loss":0,"target1":0,"target2":0,
"index_entry_level":0,"index_support":0,"index_resistance":0,"best_time":"simple text","exit_by":"date and time",
"day1":{"low":0,"high":0,"bias":"UP or DOWN or FLAT","up_pct":0,"down_pct":0,"flat_pct":0},"day2":{"low":0,"high":0,"bias":"UP or DOWN or FLAT","up_pct":0,"down_pct":0,"flat_pct":0},
"key_reasons":["simple sentence"],"risks":["simple sentence"],"events":["event with date"],"invalidate_if":"simple sentence"}''';
}
