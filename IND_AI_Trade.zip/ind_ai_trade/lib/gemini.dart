import 'dart:convert';
import 'package:http/http.dart' as http;
import 'engine.dart';

String buildPrompt(Inp i,Res r){
  final n=DateTime.now();
  final f=(double x)=>x.toStringAsFixed(2);
  return '''You are a senior Indian derivatives (NSE/BSE F&O) strategist and quant. Use live web search for today's data.
DATE/TIME: $n (IST) | INSTRUMENT: ${i.ix} INDEX OPTIONS (OPTIDX) | EXPIRY IN: ${i.dte} days
MY QUANT ENGINE: spot ${f(r.spot)}, ATR14 ${f(r.atr)}, RSI14 ${f(r.rsi)}, MACD hist ${f(r.hist)}, EMA20 ${f(r.e20)}, EMA50 ${f(r.e50)}, VWAP20 ${f(r.vwap)}, Bollinger %B ${f(r.pb)}, India VIX ${i.vix}, PCR ${i.pcr}, FUT OI change ${i.oi}%.
Composite score ${r.score.round()}/100 => ${r.bias}. Proposed: ${r.action} (${r.legs}).
TASKS:
1. Current market structure: trend, key support/resistance, pivots (CPR), gap, previous day OHLC.
2. Option chain: max pain, highest Call/Put OI strikes, OI change, PCR, IV skew, IV percentile, term structure.
3. Flows: FII/DII cash and index futures long/short ratio, GIFT Nifty, global cues (US, Dow, Nasdaq, crude, USDINR, US10Y), India VIX trend.
4. Events in next 2 sessions: RBI, results, expiry, macro data, news.
5. Greeks check (delta, gamma, theta, vega) for the proposed trade; best strikes and expiry.
6. FINAL TRADE: instrument type, index, expiry, strike(s), BUY/SELL, CE/PE, entry range, stop-loss, target 1/2, risk:reward, probability of profit, position size for 1-2% capital risk, exit rules.
7. 2-DAY OUTLOOK: for Day+1 and Day+2 give bullish/bearish/range probabilities, expected high-low range, and scenario triggers.
8. Say clearly if the proposed trade should be REJECTED, and list what would invalidate the view.
Output as a table plus a short rationale. End with: educational analysis, not SEBI-registered advice.''';
}
Future<String> askGemini(String key,String prompt)async{
  final u=Uri.parse('https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=$key');
  final res=await http.post(u,headers:{'Content-Type':'application/json'},body:jsonEncode({'contents':[{'parts':[{'text':prompt}]}],'tools':[{'google_search':{}}]}));
  try{final j=jsonDecode(res.body);return (j['candidates'][0]['content']['parts'] as List).map((p)=>p['text']??'').join();}catch(_){return res.body;}
}
