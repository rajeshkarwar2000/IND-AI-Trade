import 'engine.dart';
import 'calendar.dart';

String autoPrompt(String ix,String style,{String hint=''}){
  final n=DateTime.now();
  final idx=ix=='ANY'?'INDEX: choose the ONE best of NIFTY 50, BANK NIFTY, FINNIFTY, SENSEX for today (clearest trend, good liquidity, best risk:reward) and explain why in key_reasons.':'INDEX: $ix only.';
  final sty=style=='Intraday'?'STYLE: INTRADAY. Exit the same day before 3:15 PM IST.':style=='Swing'?'STYLE: 2-DAY SWING. Hold at most 2 trading days.':'STYLE: choose INTRADAY or SWING yourself (hold at most 2 trading days) and say which in "style".';
  return '''ROLE: You are a senior Indian index-derivatives (NSE/BSE F&O) trader and quant with 20 years of experience and strict risk discipline. The user is a beginner and will type NOTHING. You must do all research yourself with live web search and give a ready-to-use trade plan in very simple words.
NOW: $n (IST, from the user's phone). $idx $sty

VERIFIED CALENDAR (computed by the app from NSE/BSE circulars). Treat it as CORRECT. Do NOT search for holidays, market status or expiry dates. Use these exact dates. Only mention a conflict if you find an official NSE/BSE circular that contradicts it.
${calendarFacts(ix,n)}${hint.isEmpty?'':'\n$hint'}

STEP 1 - COLLECT REAL, CURRENT DATA. Note the time of each number. If MARKET STATUS above says CLOSED, use the last close and plan for the first of the next 3 trading sessions, and say so in session_note. NEVER invent a number. Use 0 or [] if you cannot find it, and lower data_quality.
- Spot, previous close, day high/low, gap; the last 35 completed daily candles (open, high, low, close), oldest first.
- India VIX level, change and 5-day trend; ATM IV and IV percentile.
- Option chain for the nearest valid expiries: PCR (OI), max pain, top 3 Call-OI and Put-OI strikes, OI changes, ATM straddle price (implied move), IV skew, live prices of the ATM CE and PE.
- Index futures: price vs OI change (long buildup, short buildup, short covering, long unwinding), basis.
- Flows: FII and DII cash flows, FII index-futures long/short ratio.
- Global and macro: GIFT Nifty, S&P 500, Nasdaq, Dow futures, US 10Y yield, Dollar index, USDINR, Brent crude.
- Events and news in the next 2 sessions: RBI, US Fed, CPI/GDP data, results of index heavyweights, expiry, holidays, major headlines.
Cross-check key numbers (spot, VIX, PCR) with at least 2 sources.

STEP 2 - ANALYSE. Multi-timeframe trend (daily, 1-hour, 15-minute); EMA 9/20/50/200, VWAP, RSI, MACD, ADX, Supertrend, Bollinger, ATR; pivots/CPR and key support/resistance; OI walls as barriers; volatility regime; breadth and sector strength (banks, IT, heavyweights).

STEP 3 - DECIDE USING THESE RULES.
- Need at least 3 independent confirmations from: trend, momentum, option-chain/OI, flows, global cues. If they are mixed, action is NO TRADE.
- Only BUY options (CALL or PUT), ATM or one strike in-the-money, on a liquid strike with a tight bid-ask. Avoid buying when VIX is very high or IV percentile is above 80, unless there is a strong breakout.
- If price is already stretched (far from VWAP/EMA20, RSI extreme), do not chase: timing = WAIT FOR DIP (call) or WAIT FOR BOUNCE (put) with an exact index level in index_entry_level.
- Avoid fresh buying on expiry day after 1 PM and just before major events.
- Expiry: chosen_expiry_date MUST be one of the VALID EXPIRIES listed above. Intraday = nearest valid expiry with at least 1 day left; 2-day swing = valid expiry at least 3 days away.
- Give a complete EXIT PLAN: exit prices (stop-loss, target 1, target 2 in option premium AND the matching index levels), an exact exit date and time, a trailing rule (for example after target 1 move stop-loss to the entry price) and a time stop (exit anyway if there is no move by a set time).
- Stop-loss about 25-30% of premium or beyond a key index level. Target 1 gives at least 1.5x the risk, target 2 at least 2.5x.
- Be honest with probabilities. Confidence above 75% only with strong agreement of signals.

STEP 4 - SELF-CHECK. Argue against your own trade. If the opposite case is equally strong, return NO TRADE.

STEP 5 - EXPERT PANEL. Before answering, act as a panel of 4 independent experts and review YOUR OWN trade: (1) technical analyst, (2) options and volatility specialist (Greeks, IV, option chain), (3) risk manager, (4) macro and flows analyst. Each votes BUY NOW, WAIT or AVOID and scores the trade 0-10. A devil's advocate gives the strongest argument against it. If the experts disagree, set action NO TRADE or timing WAIT, and panel_verdict must be WAIT or REJECT. Give the CURRENT official lot size from the NSE/BSE circular (0 if unsure) and the worst-case loss per lot at the stop-loss.

OUTPUT: reply with ONLY one JSON object. No markdown fences, no text before or after. Numbers must be numbers. Keys exactly:
{"style":"INTRADAY or SWING","session_note":"simple text","data_time":"when the data is from","data_quality":"HIGH or MEDIUM or LOW",
"market":{"index":"NIFTY or BANKNIFTY or FINNIFTY or SENSEX","spot":0,"prev_close":0,"day_high":0,"day_low":0,"vix":0,"pcr":0,"fut_oi_change_pct":0,"atm_ce_price":0,"atm_pe_price":0},
"history":[[0,0,0,0]],
"market_view":"BULLISH or BEARISH or SIDEWAYS","confidence_pct":0,"action":"BUY CALL or BUY PUT or NO TRADE","timing":"BUY NOW or WAIT FOR DIP or WAIT FOR BOUNCE or AVOID",
"instrument":"e.g. NIFTY 09 NOV 24900 CE","strike":0,"chosen_expiry_date":"YYYY-MM-DD","option_ltp":0,"entry_price_min":0,"entry_price_max":0,"stop_loss":0,"target1":0,"target2":0,
"index_entry_level":0,"index_support":0,"index_resistance":0,"index_stop_level":0,"index_target_level":0,"best_time":"simple text",
"exit_date":"YYYY-MM-DD","exit_time":"HH:MM AM/PM IST","exit_rule":"simple text: when to book profit, when to move stop-loss, and the time stop","exit_by":"date and time",
"day1":{"low":0,"high":0,"bias":"UP or DOWN or FLAT","up_pct":0,"down_pct":0,"flat_pct":0},"day2":{"low":0,"high":0,"bias":"UP or DOWN or FLAT","up_pct":0,"down_pct":0,"flat_pct":0},
"key_reasons":["simple sentence"],"risks":["simple sentence"],"events":["event with date"],"invalidate_if":"simple sentence",
"experts":[{"role":"Technical analyst","verdict":"BUY NOW or WAIT or AVOID","score":0,"point":"simple sentence","concern":"simple sentence"},{"role":"Options and volatility specialist","verdict":"BUY NOW or WAIT or AVOID","score":0,"point":"simple sentence","concern":"simple sentence"},{"role":"Risk manager","verdict":"BUY NOW or WAIT or AVOID","score":0,"point":"simple sentence","concern":"simple sentence"},{"role":"Macro and flows analyst","verdict":"BUY NOW or WAIT or AVOID","score":0,"point":"simple sentence","concern":"simple sentence"}],
"devils_advocate":"simple sentence","panel_verdict":"APPROVE or WAIT or REJECT","agree_count":0,"improvements":["simple sentence"],"better_alternative":"simple text or none","lot_size":0,"worst_case":"simple text with rupee amount"}''';
}

String schedulePrompt()=>'''You are an Indian stock-market calendar expert. Using the OFFICIAL NSE and BSE circulars (nseindia.com, bseindia.com), find: (1) all equity-derivatives trading holidays on weekdays for 2026 and 2027 (whichever are published), (2) special sessions such as Muhurat trading, (3) the CURRENT weekly and monthly index-options expiry weekday for NIFTY, BANKNIFTY, FINNIFTY (NSE) and SENSEX (BSE). Do not guess. Skip anything you cannot verify.
Reply with ONLY one JSON object, no markdown, no extra text. Weekday numbers: Monday=1 ... Friday=5.
{"updated":"YYYY-MM-DD","holidays":{"YYYY-MM-DD":"holiday name"},"special_sessions":{"YYYY-MM-DD":"name"},"weekly":{"NIFTY":2,"SENSEX":4},"monthly":{"NIFTY":2,"BANKNIFTY":2,"FINNIFTY":2,"SENSEX":4}}
Include only indices that really have that expiry type (BANKNIFTY and FINNIFTY have no weekly expiry).''';
