import 'dart:convert';
import 'engine.dart';
double nm(dynamic v)=>v is num?v.toDouble():(double.tryParse((v?.toString()??'').replaceAll(RegExp(r'[^0-9.\-]'),''))??0);
String sx(dynamic v)=>v?.toString()??'';
class Gem{
  final Map<String,dynamic> j;Gem(this.j);
  double num_(String k)=>nm(j[k]);String str(String k)=>sx(j[k]);
  List<String> list(String k){final v=j[k];return v is List?v.map((e)=>e.toString()).toList():<String>[];}
  double d(String k,String f){final m=j[k];return m is Map?nm(m[f]):0;}
  String ds(String k,String f){final m=j[k];return m is Map?sx(m[f]):'';}
  String get action=>str('action').toUpperCase();
  String get timing=>str('timing').toUpperCase();
}
Gem? parseGem(String t){final a=t.indexOf('{'),b=t.lastIndexOf('}');if(a<0||b<=a)return null;
  try{final m=jsonDecode(t.substring(a,b+1));return m is Map<String,dynamic>?Gem(m):null;}catch(_){return null;}}
class Fin{String title='',sub='',kind='';List<List<String>> rows=[];List<String> reasons=[],risks=[];String invalid='';}
String _dir(String a)=>(a.contains('BUY CALL')||a.contains('SELL PUT'))?'UP':(a.contains('BUY PUT')||a.contains('SELL CALL'))?'DOWN':'NONE';
Fin decide(Res e,Gem g){
  final f=Fin(),de=_dir(e.action),dg=_dir(g.action);
  final wait=g.timing.contains('WAIT')||e.when.startsWith('WAIT');
  f.reasons=g.list('key_reasons');f.risks=[...g.list('risks'),...g.list('events')];f.invalid=g.str('invalidate_if');
  if(de=='NONE'||dg=='NONE'||de!=dg){
    f.kind='stop';f.title='NO TRADE - WAIT';
    f.sub=(de!='NONE'&&dg!='NONE')?'The app and Gemini disagree on direction. Skip this trade.':'No clear chance from the app or Gemini. Staying out is a smart trade.';
    f.rows=[['App says',e.action],['Gemini says',g.action.isEmpty?'-':g.action],['Gemini market view',g.str('market_view')]];
    return f;
  }
  f.kind=wait?'wait':'go';f.title=g.action;
  f.sub=wait?(dg=='UP'?'WAIT FOR A SMALL DIP':'WAIT FOR A SMALL BOUNCE'):'BUY NOW';
  final lo=g.num_('entry_price_min'),hi=g.num_('entry_price_max');
  var sl=g.num_('stop_loss');final ent=lo>0?lo:e.entry;if(sl<=0||sl>=ent)sl=e.sl;
  final lvl=g.num_('index_entry_level')>0?g.num_('index_entry_level'):e.dipLevel;
  String t(String k,String d)=>g.str(k).isEmpty?d:g.str(k);
  f.rows=[
    ['Both agree',dg=='UP'?'Market likely UP':'Market likely DOWN'],
    ['Confidence','${((e.conv+g.num_('confidence_pct'))/2).round()}%'],
    ['Search in broker app',t('instrument',e.legs)],
    ['Date and time now','${fd(DateTime.now())}'],
    ['Buy price (about)',lo>0?'Rs ${lo.toStringAsFixed(0)} to ${(hi>lo?hi:lo).toStringAsFixed(0)}':'Rs ${e.entry.toStringAsFixed(2)}'],
    if(wait&&lvl>0)['Buy when index is near',lvl.toStringAsFixed(0)],
    ['Exit if price falls to (stop-loss)','Rs ${sl.toStringAsFixed(0)}'],
    ['Take profit 1','Rs ${(g.num_('target1')>0?g.num_('target1'):e.tgt).toStringAsFixed(0)}'],
    if(g.num_('target2')>0)['Take profit 2','Rs ${g.num_('target2').toStringAsFixed(0)}'],
    ['Index support / resistance','${g.num_('index_support').toStringAsFixed(0)} / ${g.num_('index_resistance').toStringAsFixed(0)}'],
    ['Best time to enter',t('best_time',e.timeWin)],
    ['Exit by',t('exit_by',e.exitBy)],
  ];
  return f;
}

(Inp,Res)? engineFromGem(Gem g,String style,bool simple){
  try{
    final m=g.j['market'];if(m is! Map)return null;
    final sp=nm(m['spot']);if(sp<=0)return null;
    final ex=DateTime.tryParse(sx(g.j['chosen_expiry_date']))??DateTime.now().add(const Duration(days:3));
    final n=DateTime.now();var dte=DateTime(ex.year,ex.month,ex.day).difference(DateTime(n.year,n.month,n.day)).inDays;if(dte<0)dte=0;
    final bars=<Bar>[];final h=g.j['history'];
    if(h is List){for(final row in h){if(row is List&&row.length>=4){final c=nm(row[3]);if(c>0)bars.add(Bar(nm(row[0]),nm(row[1]),nm(row[2]),c,1));}}}
    final ix=sx(m['index']).toUpperCase().replaceAll(' ','');
    final key=steps.containsKey(ix)?ix:(ix.contains('BANK')?'BANKNIFTY':ix.contains('FIN')?'FINNIFTY':ix.contains('SENSEX')?'SENSEX':'NIFTY');
    Inp mk(double live)=>Inp(ix:key,style:style,vix:nm(m['vix'])>0?nm(m['vix']):15.0,pcr:nm(m['pcr'])>0?nm(m['pcr']):1.0,oi:nm(m['fut_oi_change_pct']),
      spot:sp,live:live,prev:nm(m['prev_close']),dte:dte,simple:simple,expiry:ex,bars:bars);
    var i=mk(0);var r=analyze(i);
    final live=r.action=='BUY CALL'?nm(m['atm_ce_price']):r.action=='BUY PUT'?nm(m['atm_pe_price']):0.0;
    if(live>0){i=mk(live);r=analyze(i);}
    return (i,r);
  }catch(_){return null;}
}
