import 'dart:convert';
import 'engine.dart';
import 'calendar.dart';
double nm(dynamic v)=>v is num?v.toDouble():(double.tryParse((v?.toString()??'').replaceAll(RegExp(r'[^0-9.\-]'),''))??0);
String sx(dynamic v)=>v?.toString()??'';
class Gem{
  final Map<String,dynamic> j;Gem(this.j);
  double num_(String k)=>nm(j[k]);String str(String k)=>sx(j[k]);
  List<String> list(String k){final v=j[k];return v is List?v.map((e)=>e.toString()).toList():<String>[];}
  double d(String k,String f){final m=j[k];return m is Map?nm(m[f]):0;}
  String ds(String k,String f){final m=j[k];return m is Map?sx(m[f]):'';}
  String get action=>str('action').toUpperCase();
  String get timing=>str('timing').toUpperCase();
}
Gem? parseGem(String t){final a=t.indexOf('{'),b=t.lastIndexOf('}');if(a<0||b<=a)return null;
  try{final m=jsonDecode(t.substring(a,b+1));return m is Map<String,dynamic>?Gem(m):null;}catch(_){return null;}}
class Fin{String title='',sub='',kind='';List<List<String>> rows=[];List<String> reasons=[],risks=[];String invalid='';}
String _dir(String a)=>(a.contains('BUY CALL')||a.contains('SELL PUT'))?'UP':(a.contains('BUY PUT')||a.contains('SELL CALL'))?'DOWN':'NONE';
Fin decide(Res e,Gem g){
  final f=Fin(),de=_dir(e.action),dg=_dir(g.action);final pv=g.str('panel_verdict').toUpperCase();
  final wait=g.timing.contains('WAIT')||e.when.startsWith('WAIT')||pv.contains('WAIT');
  f.reasons=g.list('key_reasons');f.risks=[...g.list('risks'),...g.list('events')];f.invalid=g.str('invalidate_if');
  if(de=='NONE'||dg=='NONE'||de!=dg||pv.contains('REJECT')){
    f.kind='stop';f.title='NO TRADE - WAIT';
    f.sub=pv.contains('REJECT')?'The expert panel rejected this trade. Skip it.':(de!='NONE'&&dg!='NONE')?'The app and Gemini disagree on direction. Skip this trade.':'No clear chance from the app or Gemini. Staying out is a smart trade.';
    f.rows=[['App says',e.action],['Gemini says',g.action.isEmpty?'-':g.action],['Gemini market view',g.str('market_view')]];
    return f;
  }
  f.kind=wait?'wait':'go';f.title=g.action;
  f.sub=wait?(dg=='UP'?'WAIT FOR A SMALL DIP':'WAIT FOR A SMALL BOUNCE'):'BUY NOW';
  final lo=g.num_('entry_price_min'),hi=g.num_('entry_price_max');
  var sl=g.num_('stop_loss');final ent=lo>0?lo:e.entry;if(sl<=0||sl>=ent)sl=e.sl;
  final lvl=g.num_('index_entry_level')>0?g.num_('index_entry_level'):e.dipLevel;
  String t(String k,String d)=>g.str(k).isEmpty?d:g.str(k);
  f.rows=[
    ['Both agree',dg=='UP'?'Market likely UP':'Market likely DOWN'],
    if(pv.isNotEmpty)['Expert panel','$pv (${g.num_('agree_count').round()} of 4 agree)'],
    ['Confidence','${((e.conv+g.num_('confidence_pct'))/2).round()}%'],
    ['Search in broker app',t('instrument',e.legs)],
    ['Date and time now','${fd(DateTime.now())}'],
    ['Buy price (about)',lo>0?'Rs ${lo.toStringAsFixed(0)} to ${(hi>lo?hi:lo).toStringAsFixed(0)}':'Rs ${e.entry.toStringAsFixed(2)}'],
    if(wait&&lvl>0)['Buy when index is near',lvl.toStringAsFixed(0)],
    ['Exit if price falls to (stop-loss)','Rs ${sl.toStringAsFixed(0)}'],
    ['Take profit 1','Rs ${(g.num_('target1')>0?g.num_('target1'):e.tgt).toStringAsFixed(0)}'],
    if(g.num_('target2')>0)['Take profit 2','Rs ${g.num_('target2').toStringAsFixed(0)}'],
    ['Index support / resistance','${g.num_('index_support').toStringAsFixed(0)} / ${g.num_('index_resistance').toStringAsFixed(0)}'],
    ['Best time to enter',t('best_time',e.timeWin)],
    ['Exit date and time',g.str('exit_date').isNotEmpty?'${g.str('exit_date')}, ${g.str('exit_time')}':t('exit_by',e.exitBy)],
    ['Exit rule',t('exit_rule','Exit at the stop-loss or the target, whichever comes first.')],
  ];
  return f;
}

(Inp,Res)? engineFromGem(Gem g,String style,bool simple){
  try{
    final m=g.j['market'];if(m is! Map)return null;
    final sp=nm(m['spot']);if(sp<=0)return null;
    final ix=sx(m['index']).toUpperCase().replaceAll(' ','');
    final ik=steps.containsKey(ix)?ix:(ix.contains('BANK')?'BANKNIFTY':ix.contains('FIN')?'FINNIFTY':ix.contains('SENSEX')?'SENSEX':'NIFTY');
    final now=DateTime.now();final ex0=DateTime.tryParse(sx(g.j['chosen_expiry_date']));String? fix;
    final cand=expiries(ik,now,weeks:12);DateTime exd;
    if(cand.isNotEmpty&&(ex0==null||!cand.any((e)=>e.date==dOnly(ex0)))){
      final nx=nearestExpiry(cand,ex0);fix='Gemini gave expiry ${ex0==null?'(none)':fdate(ex0)}, which is not a valid $ik expiry. The app used ${fdate(nx)}. Check the strike in your broker app.';exd=nx;
    }else{exd=ex0??now.add(const Duration(days:3));}
    var dte=dOnly(exd).difference(dOnly(now)).inDays;if(dte<0)dte=0;
    final bars=<Bar>[];final h=g.j['history'];
    if(h is List){for(final row in h){if(row is List&&row.length>=4){final c=nm(row[3]);if(c>0)bars.add(Bar(nm(row[0]),nm(row[1]),nm(row[2]),c,1));}}}
    Inp mk(double live)=>Inp(ix:ik,style:style,vix:nm(m['vix'])>0?nm(m['vix']):15.0,pcr:nm(m['pcr'])>0?nm(m['pcr']):1.0,oi:nm(m['fut_oi_change_pct']),
      spot:sp,live:live,prev:nm(m['prev_close']),dte:dte,simple:simple,expiry:exd,bars:bars);
    var i=mk(0);var r=analyze(i);
    final live=r.action=='BUY CALL'?nm(m['atm_ce_price']):r.action=='BUY PUT'?nm(m['atm_pe_price']):0.0;
    if(live>0){i=mk(live);r=analyze(i);}
    if(fix!=null)r.notes.insert(0,fix);
    return (i,r);
  }catch(_){return null;}
}

class Chk{final String t,why;final bool? ok;Chk(this.t,this.ok,this.why);}
List<Chk> checklist(Res e,Inp i,Gem? g){
  final buy=e.action.startsWith('BUY'),de=_dir(e.action),l=<Chk>[];
  l.add(Chk('App and Gemini agree',g==null?null:(de!='NONE'&&de==_dir(g.action)),g==null?'Paste the Gemini reply on the Auto tab to check':'App: ${e.action} | Gemini: ${g.action}'));
  l.add(Chk('Clear direction',e.score.abs()>=40,'Score ${e.score.round()} (needs 40 or more, up or down)'));
  l.add(Chk('Not chasing the move',buy?e.when=='BUY NOW':null,e.when.isEmpty?'-':e.when));
  l.add(Chk('Fear meter (VIX) not too high',i.vix<=18,'VIX ${i.vix}'));
  final need=e.style.startsWith('2')?3:1;
  l.add(Chk('Enough days to expiry',i.dte>=need,'${i.dte} days left, need $need or more'));
  if(buy&&e.entry>e.sl&&e.sl>0){final rr=(e.tgt-e.entry)/(e.entry-e.sl);l.add(Chk('Reward at least 1.5x the risk',rr>=1.5,'Reward is ${rr.toStringAsFixed(1)}x the risk'));}
  l.add(Chk('Real price history used',e.hasH,e.hasH?'30+ daily candles':'No history, chart signals were skipped'));
  l.add(Chk('Expiry date is valid',!e.notes.any((n)=>n.contains('not a valid')),'Checked with the built-in calendar'));
  final st=status(DateTime.now());
  l.add(Chk('Market is open now',st.startsWith('OPEN')?true:null,st));
  if(g!=null){
    l.add(Chk('Gemini data quality is HIGH',g.str('data_quality').toUpperCase()=='HIGH',g.str('data_quality').isEmpty?'not given':g.str('data_quality')));
    l.add(Chk('Gemini confidence 65% or more',g.num_('confidence_pct')>=65,'${g.num_('confidence_pct').round()}%'));
    if(g.str('panel_verdict').isNotEmpty)l.add(Chk('Expert panel approves',g.str('panel_verdict').toUpperCase().contains('APPROVE'),g.str('panel_verdict')));
    final ev=g.list('events');l.add(Chk('No big event coming',ev.isEmpty,ev.isEmpty?'None reported':ev.first));
  }
  return l;
}
