import 'dart:math' as math;
import 'dart:ui';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:android_intent_plus/android_intent.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'engine.dart';
import 'merge.dart';
import 'calendar.dart';
import 'gemini.dart';

const kG2=Color(0xFF74747F),kG3=Color(0xFF8E8E99),kAmber=Color(0xFFC77C00);
class GlassCfg{
  double blur=26,op=.60,border=.95,radius=30,depth=.55;int tint=0xFFFFFFFF,accent=0xFF64B5FF;bool light=true,anim=false;
  GlassCfg copy()=>GlassCfg()..blur=blur..op=op..border=border..radius=radius..depth=depth..tint=tint..accent=accent..light=light..anim=anim;
}
final cfg=ValueNotifier<GlassCfg>(GlassCfg());
Future<void> loadCfg()async{final p=await SharedPreferences.getInstance();final g=GlassCfg();
  if(p.getBool('light')!=null){g.light=p.getBool('light')!;g.blur=p.getDouble('blur')??g.blur;g.op=p.getDouble('op')??g.op;g.border=p.getDouble('border')??g.border;
    g.radius=p.getDouble('radius')??g.radius;g.depth=p.getDouble('depth')??g.depth;g.tint=p.getInt('tint')??g.tint;g.accent=p.getInt('accent')??g.accent;g.anim=p.getBool('anim')??false;}
  cfg.value=g;}
Future<void> saveCfg(GlassCfg g)async{final p=await SharedPreferences.getInstance();
  await p.setDouble('blur',g.blur);await p.setDouble('op',g.op);await p.setDouble('border',g.border);await p.setDouble('radius',g.radius);await p.setDouble('depth',g.depth);
  await p.setInt('tint',g.tint);await p.setInt('accent',g.accent);await p.setBool('light',g.light);await p.setBool('anim',g.anim);}
void main()async{WidgetsFlutterBinding.ensureInitialized();await loadCfg();await loadSchedule();
  runApp(ValueListenableBuilder<GlassCfg>(valueListenable:cfg,builder:(c,g,_)=>MaterialApp(debugShowCheckedModeBanner:false,title:'IND AI Trade',
    theme:g.light?ThemeData.light(useMaterial3:true):ThemeData.dark(useMaterial3:true),home:const Home())));}

class Glass extends StatelessWidget{
  final Widget child;final EdgeInsets p;
  const Glass(this.child,{super.key,this.p=const EdgeInsets.all(16)});
  @override Widget build(BuildContext c)=>ValueListenableBuilder<GlassCfg>(valueListenable:cfg,builder:(c,g,_){final tint=Color(g.tint),L=g.light,br=BorderRadius.circular(g.radius);
    return Padding(padding:const EdgeInsets.only(bottom:12),child:Container(
      decoration:BoxDecoration(borderRadius:br,boxShadow:[BoxShadow(color:(L?const Color(0xFF4A5A8A):Colors.black).withOpacity((L?.16:.35)*g.depth),blurRadius:12+30*g.depth,offset:Offset(0,4+12*g.depth))]),
      child:ClipRRect(borderRadius:br,child:BackdropFilter(filter:ImageFilter.blur(sigmaX:g.blur+.01,sigmaY:g.blur+.01),child:Container(padding:p,
        decoration:BoxDecoration(borderRadius:br,border:Border.all(color:Colors.white.withOpacity(g.border),width:L?1.3:1),
          gradient:LinearGradient(begin:Alignment.topLeft,end:Alignment.bottomRight,colors:[tint.withOpacity(g.op),tint.withOpacity(g.op*(L?.6:.25))])),child:child)))));});
}

class Home extends StatefulWidget{const Home({super.key});@override State<Home> createState()=>_S();}
class _S extends State<Home> with SingleTickerProviderStateMixin{
  late final AnimationController ac;
  int t=0;String ix='NIFTY',note='',ai='',style='Auto',pick='ANY';bool busy=false,simple=true;Res? r;Inp? inp;Gem? panel;Gem? gem;String gerr='',sched='',perr='';DateTime expiry=DateTime.now().add(const Duration(days:3));
  final vix=TextEditingController(text:'14.5'),pcr=TextEditingController(text:'1.05'),oi=TextEditingController(text:'2'),
    spot=TextEditingController(),live=TextEditingController(),prevC=TextEditingController(),csv=TextEditingController(),paste=TextEditingController(),su=TextEditingController(text:Cal.url),capC=TextEditingController(text:'100000'),rskC=TextEditingController(text:'1');
  static const gn=Color(0xFF1FA84A),rd=Color(0xFFE5392F),bl=Color(0xFF0A84FF);

  @override void initState(){super.initState();ac=AnimationController(vsync:this,duration:const Duration(seconds:30))..repeat();cfg.addListener(()=>setState((){}));if(Cal.url.isNotEmpty)fetchSchedule(Cal.url).then((_){if(mounted)setState((){});});}
  int days(){final n=DateTime.now();final d=DateTime(expiry.year,expiry.month,expiry.day).difference(DateTime(n.year,n.month,n.day)).inDays;return d<0?0:d;}
  Future<void> pickExpiry()async{final n=DateTime.now();final d=await showDatePicker(context:context,initialDate:expiry.isBefore(n)?n:expiry,firstDate:n.subtract(const Duration(days:1)),lastDate:n.add(const Duration(days:400)));if(d!=null)setState(()=>expiry=d);}
  Widget cap(String s)=>Padding(padding:const EdgeInsets.only(bottom:8),child:Text(s,style:const TextStyle(color:kG3,fontSize:11)));
  @override void dispose(){ac.dispose();super.dispose();}
  void run(){final b=parseCsv(csv.text);final sp=double.tryParse(spot.text)??0;note='';
    if(sp<=0&&b.length<30){setState((){r=null;note='Please type the index price now (first box).';});return;}
    inp=Inp(ix:ix,style:style,vix:double.tryParse(vix.text)??15,pcr:double.tryParse(pcr.text)??1,oi:double.tryParse(oi.text)??0,spot:sp,live:double.tryParse(live.text)??0,
      prev:double.tryParse(prevC.text)??0,dte:days(),simple:simple,expiry:expiry,bars:b);
    r=analyze(inp!);setState((){});}

  Future<void> toGemini()async{final x=r;if(x==null)return;await sendPrompt(autoPrompt(inp!.ix,style,hint:manualHint(inp!)));}
  Future<void> sendPrompt(String p)async{
    await Clipboard.setData(ClipboardData(text:p));
    try{await AndroidIntent(action:'android.intent.action.SEND',package:'com.google.android.apps.bard',type:'text/plain',arguments:{'android.intent.extra.TEXT':p}).launch();}
    catch(_){try{await const AndroidIntent(action:'action_view',data:'https://gemini.google.com/app').launch();}catch(_){}}
    if(mounted)ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('Prompt copied. If the box is empty in Gemini, long-press and Paste.')));}
  Widget tf(String l,TextEditingController c,{int lines=1,bool hide=false})=>Padding(padding:const EdgeInsets.only(bottom:8),child:TextField(controller:c,maxLines:lines,obscureText:hide,
    keyboardType:lines>1||hide?TextInputType.multiline:const TextInputType.numberWithOptions(decimal:true),
    decoration:InputDecoration(labelText:l,filled:true,fillColor:cfg.value.light?Colors.black.withOpacity(.05):Colors.white.withOpacity(.08),border:OutlineInputBorder(borderRadius:BorderRadius.circular(14),borderSide:BorderSide.none))));
  Widget kv(String k,String v,[Color? c])=>Padding(padding:const EdgeInsets.symmetric(vertical:3),child:Row(mainAxisAlignment:MainAxisAlignment.spaceBetween,
    children:[Flexible(child:Text(k,style:const TextStyle(color:kG2))),const SizedBox(width:12),Flexible(child:Text(v,textAlign:TextAlign.right,style:TextStyle(fontWeight:FontWeight.w600,color:c)))]));
  Widget btn(String s,VoidCallback f)=>SizedBox(width:double.infinity,child:CupertinoButton.filled(onPressed:f,child:Text(s)));
  Widget blob(Color c,[double sz=280])=>Container(width:sz*1.6,height:sz*1.6,decoration:BoxDecoration(shape:BoxShape.circle,gradient:RadialGradient(colors:[c.withOpacity(cfg.value.light?.7:.6),c.withOpacity(0)])));
  Widget bg(GlassCfg g)=>AnimatedBuilder(animation:ac,builder:(c,_){final t0=g.anim?ac.value*2*math.pi:0.0;
    Widget b(Color col,double x,double y,double ph,double sz)=>Align(alignment:Alignment(x+.28*math.sin(t0+ph),y+.22*math.cos(t0*.8+ph)),child:blob(col,sz));
    return Stack(fit:StackFit.expand,children:[Container(color:g.light?Colors.white:const Color(0xFF05070F)),
      b(Color(g.accent),-.9,-.8,0,300),b(g.light?const Color(0xFFFFB3D9):const Color(0xFFBF5AF2),.95,.35,2,300),
      if(g.light)b(const Color(0xFF9BF0D6),-.7,.95,4,260),if(g.light)b(const Color(0xFFFFE29A),.9,-.9,1,200)]);});
  Widget nav(int i,IconData ic,String l)=>GestureDetector(onTap:()=>setState(()=>t=i),child:Column(mainAxisSize:MainAxisSize.min,children:[
    Icon(ic,color:t==i?bl:kG3),Text(l,style:TextStyle(fontSize:11,color:t==i?bl:kG3))]));
  String dt(int n){var d=DateTime.now();for(var i=0;i<n;i++){do{d=d.add(const Duration(days:1));}while(d.weekday>5);}
    const m=['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];return '${d.day} ${m[d.month-1]}';}
  String f0(double x)=>x.toStringAsFixed(0);
  String f2(double x)=>x.toStringAsFixed(2);

  List<Widget> signal(){
    final w=<Widget>[Glass(Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
      SizedBox(width:double.infinity,child:CupertinoSlidingSegmentedControl<String>(groupValue:ix,
        children:{for(final k in steps.keys)k:Padding(padding:const EdgeInsets.all(6),child:Text(k,style:const TextStyle(fontSize:11)))},onValueChanged:(v)=>setState(()=>ix=v!))),
      const SizedBox(height:10),const Text('Trading style',style:TextStyle(color:kG2)),const SizedBox(height:6),
      SizedBox(width:double.infinity,child:CupertinoSlidingSegmentedControl<String>(groupValue:style,
        children:const{'Auto':Padding(padding:EdgeInsets.all(8),child:Text('Auto')),'Intraday':Padding(padding:EdgeInsets.all(8),child:Text('Intraday')),'Swing':Padding(padding:EdgeInsets.all(8),child:Text('2-Day'))},
        onValueChanged:(v)=>setState(()=>style=v!))),
      cap('Intraday = buy and sell the same day. 2-Day = hold up to 2 days. Auto = app decides.'),
      SwitchListTile(contentPadding:EdgeInsets.zero,title:const Text('Beginner mode (only buy CALL / PUT)'),value:simple,onChanged:(v)=>setState(()=>simple=v)),
      Row(children:[Expanded(child:tf('Index price now (Spot)',spot)),const SizedBox(width:8),Expanded(child:tf('Yesterday close',prevC))]),
      Row(children:[Expanded(child:tf('Fear meter (India VIX)',vix)),const SizedBox(width:8),Expanded(child:tf('Put/Call ratio (PCR)',pcr))]),
      Row(children:[Expanded(child:tf('Futures OI change %',oi)),const SizedBox(width:8),Expanded(child:tf('Live option price (optional)',live))]),
      cap('VIX above 16 = options are costly. PCR above 1 = slightly bullish. OI change = more positions opened today (+) or closed (-). Live option price = the price you see in your broker app for the strike below.'),
      OutlinedButton(onPressed:pickExpiry,child:Text('Expiry date: ${fd(expiry)}  (${days()} days left) - tap to change')),
      const SizedBox(height:8),tf('Optional: paste daily history  o,h,l,c,v  (30+ rows)',csv,lines:2),btn('Analyze',run)]))];
    if(note.isNotEmpty)w.add(Text(note,style:const TextStyle(color:kAmber,fontSize:13)));
    final x=r;if(x==null)return w;
    final col=x.score>=25?gn:x.score<=-25?rd:kAmber,buy=x.action.startsWith('BUY'),trade=x.entry>0;
    w.add(Glass(Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
      Text(x.action,style:TextStyle(fontSize:26,fontWeight:FontWeight.w800,color:col)),
      Text(x.plain,style:const TextStyle(color:kG2)),const SizedBox(height:8),
      if(trade)Text(x.when,style:TextStyle(fontSize:20,fontWeight:FontWeight.w700,color:x.when.startsWith('WAIT')?kAmber:gn)),
      const Divider(height:20),
      kv('Date and time now','${fd(DateTime.now())}, ${TimeOfDay.now().format(context)}'),
      kv('Instrument','Index Option (OPTIDX)'),kv('Search in broker app',x.legs),kv('Trading style',x.style),
      kv('Market view','${x.bias}, score ${x.score.round()}'),kv('Confidence','${x.conv.round()}%'),
      if(trade)...[
        kv(buy?'Buy price (about)':'Money you receive','Rs ${f2(x.entry)}'),
        if(buy)kv('Do not pay above','Rs ${f2(x.maxBuy)}'),
        if(buy&&x.when.startsWith('WAIT'))kv('Buy when index is near',f0(x.dipLevel)),
        kv(buy?'Exit if price falls to (stop-loss)':'Exit if loss reaches','Rs ${f2(x.sl)}',rd),
        kv(buy?'Take profit at':'Close when price drops to','Rs ${f2(x.tgt)}',gn),
        if(buy)kv('Loss per unit if stop-loss hits','Rs ${f2(x.entry-x.sl)}'),
        kv('Best time to enter',x.timeWin),kv('Exit by',x.exitBy)],
      if(buy)...[kv('Option moves per 1 index point','Rs ${f2(x.delta.abs())}'),kv('Time loss per day','Rs ${f2(x.theta.abs())}')],
      kv('Index price',f2(x.spot)),kv('Normal daily move',f0(x.atr)+' points'),
      for(final n in x.notes)Padding(padding:const EdgeInsets.only(top:6),child:Text('- $n',style:const TextStyle(color:kG2,fontSize:12)))])));
    w.add(Glass(Column(children:[const Align(alignment:Alignment.centerLeft,child:Text('Why? (plus = up, minus = down)',style:TextStyle(fontWeight:FontWeight.w700))),
      for(final e in x.parts.entries)kv(e.key,(e.value>0?'+':'')+f0(e.value),e.value>0?gn:e.value<0?rd:null)])));
    w.add(btn('Send to Gemini app (paste the reply on the Auto tab)',toGemini));
    w.add(const Padding(padding:EdgeInsets.only(top:8),child:Text('Learning tool, not SEBI-registered advice. Options can lose all money.',style:TextStyle(color:kG3,fontSize:11))));
    return w;
  }
  List<Widget> forecast()=>[...forecast0(),...gemDays()];
  List<Widget> gemDays(){final g=gem;if(g==null)return [];final ss=sessions(DateTime.now(),3);
    return [if(g.str('three_day_trend').isNotEmpty)Glass(Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
        const Text('GEMINI: NEXT 3 TRADING SESSIONS',style:TextStyle(color:kG3,fontSize:12)),
        Text('Trend: ${g.str('three_day_trend')}',style:const TextStyle(fontSize:20,fontWeight:FontWeight.w800)),
        if(g.str('three_day_summary').isNotEmpty)Text(g.str('three_day_summary'),style:const TextStyle(color:kG2))])),
      for(var i=0;i<3;i++)if(g.d('day${i+1}','high')>0)Glass(Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
        Text('Gemini view: ${g.ds('day${i+1}','date').isNotEmpty?g.ds('day${i+1}','date'):fdate(ss[i])}',style:const TextStyle(fontSize:16,fontWeight:FontWeight.w700)),
        kv('Likely range','${f0(g.d('day${i+1}','low'))} to ${f0(g.d('day${i+1}','high'))}'),kv('Direction',g.ds('day${i+1}','bias')),
        kv('UP / DOWN / FLAT','${f0(g.d('day${i+1}','up_pct'))}% / ${f0(g.d('day${i+1}','down_pct'))}% / ${f0(g.d('day${i+1}','flat_pct'))}%')]))];}
  List<Widget> forecast0(){final x=r;if(x==null)return [const Glass(Text('Run the Auto tab first.'))];
    return [for(var i=0;i<3;i++)Glass(Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
      Text('App view: ${fdate(sessions(DateTime.now(),3)[i])}',style:const TextStyle(fontSize:18,fontWeight:FontWeight.w700)),const SizedBox(height:6),
      kv('Likely range','${f0(x.days[i][0])} to ${f0(x.days[i][2])}'),kv('Best guess',f0(x.days[i][1]))])),
      Glass(Column(children:[kv('Chance market goes UP','${(x.pUp*100).round()}%',gn),kv('Chance market goes DOWN','${(x.pDn*100).round()}%',rd),kv('Chance it stays flat','${(x.pFlat*100).round()}%'),
      const SizedBox(height:6),const Text('Rough estimate from the fear meter (VIX) and today\'s score. Holidays are not counted.',style:TextStyle(color:kG3,fontSize:11))]))];}
  Future<void> pasteReply(bool clip)async{var t=paste.text;
    if(clip){final d=await Clipboard.getData('text/plain');t=d?.text??'';paste.text=t;}
    final g=parseGem(t);(Inp,Res)? er;if(g!=null)er=engineFromGem(g,style,simple);
    setState((){gem=g;panel=(g!=null&&g.j['experts'] is List)?g:null;if(g!=null)t=0;inp=er?.$1;r=er?.$2;gerr=g==null?'Could not read the reply. Copy the full Gemini reply. It starts with { and ends with }. If Gemini wrote normal text, ask it: "Give only the JSON".':'';});}
  Widget calCard(){final now=DateTime.now(),ss=sessions(now,3),closed=status(now).startsWith('CLOSED')||status(now).startsWith('Not');
    return Glass(Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
      const Text('MARKET STATUS (from built-in calendar)',style:TextStyle(color:kG3,fontSize:12)),
      Text(status(now),style:TextStyle(fontSize:17,fontWeight:FontWeight.w700,color:closed?kAmber:gn)),const SizedBox(height:6),
      kv('Today',fdate(now)),kv('Next 3 trading days',ss.map((d)=>fdate(d)).join('\n')),kv('Schedule data',Cal.updated),
      if(!Cal.hol.keys.any((k)=>k.startsWith('${now.year}')))const Text('Holiday list for this year is missing. Update it in Settings.',style:TextStyle(color:kAmber,fontSize:12))]));}
  Future<void> schedMsg(Future<bool> f,String okMsg)async{final ok=await f;setState(()=>sched=ok?okMsg:'Could not read or apply this schedule. Nothing was changed.');}
  Widget schedCard()=>Glass(Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
    const Text('Market schedule (holidays and expiry dates)',style:TextStyle(fontSize:18,fontWeight:FontWeight.w700)),const SizedBox(height:6),
    kv('Source',Cal.updated),kv('Holidays loaded','${Cal.hol.length} (${Cal.years()})'),
    kv('Weekly expiry',Cal.weekly.entries.map((e)=>'${e.key} ${wdName(e.value)}').join(', ')),
    kv('Monthly expiry (last)',Cal.monthly.entries.map((e)=>'${e.key} ${wdName(e.value)}').join(', ')),
    const SizedBox(height:8),tf('Auto-update link (optional): schedule.json',su),
    btn('Save link and update now',()async{Cal.url=su.text.trim();await saveUrl(Cal.url);await schedMsg(fetchSchedule(Cal.url),'Schedule updated from the link.');}),
    CupertinoButton(padding:EdgeInsets.zero,child:const Text('Update schedule with Gemini'),onPressed:()=>sendPrompt(schedulePrompt())),
    CupertinoButton(padding:EdgeInsets.zero,child:const Text('Paste Gemini schedule reply'),onPressed:()async{final d=await Clipboard.getData('text/plain');await schedMsg(applySchedule(d?.text??''),'Schedule updated from the Gemini reply.');}),
    CupertinoButton(padding:EdgeInsets.zero,child:const Text('Reset to built-in schedule'),onPressed:()async{await resetSchedule();setState(()=>sched='Reset to the built-in schedule.');}),
    if(sched.isNotEmpty)Text(sched,style:const TextStyle(color:kAmber,fontSize:13)),
    cap('Auto-update: with a link set, the app checks it every time it opens. Upload schedule.json to your GitHub repo, open it, tap Raw, and paste that link here. When NSE changes a holiday, edit the file on GitHub. No rebuild needed.')]));
  String manualHint(Inp i)=>'USER-PROVIDED DATA (use it only if it matches the live market, otherwise correct it): index ${i.ix}, spot ${i.spot}, yesterday close ${i.prev}, India VIX ${i.vix}, PCR ${i.pcr}, futures OI change ${i.oi}%, live option price ${i.live}, expiry ${fd(i.expiry)}.';
  String tradeSummary(){final x=r;if(x==null)return 'No trade proposed yet. Pick the best one yourself.';final g=gem;
    return 'APP: ${x.action} ${x.legs}, ${x.when}, entry about ${f2(x.entry)}, stop-loss ${f2(x.sl)}, target ${f2(x.tgt)}, score ${x.score.round()}. '+(g==null?'':'GEMINI: ${g.action} ${g.str('instrument')}, ${g.timing}, entry ${g.num_('entry_price_min')}-${g.num_('entry_price_max')}, stop-loss ${g.num_('stop_loss')}, target1 ${g.num_('target1')}, expiry ${g.str('chosen_expiry_date')}.');}
  Future<void> pasteExpert(bool clip)async{var t=paste.text;if(clip){final d=await Clipboard.getData('text/plain');t=d?.text??'';}
    final g=parseGem(t);setState((){panel=g;perr=g==null?'Could not read the reply. Copy the full reply. It starts with { and ends with }. If Gemini wrote normal text, ask it: "Give only the JSON".':'';});}
  Color vcol(String v)=>v.toUpperCase().contains('BUY')||v.toUpperCase().contains('APPROVE')?gn:v.toUpperCase().contains('AVOID')||v.toUpperCase().contains('REJECT')?rd:kAmber;
  List<Widget> chkCards(){final x=r,i=inp;
    if(x==null||i==null)return [const Glass(Text('Run the Auto tab first. The checklist then appears here.'))];
    if(!x.action.startsWith('BUY'))return [const Glass(Text('The app found no trade to check. Staying out is fine.'))];
    final l=checklist(x,i,gem);final pass=l.where((c)=>c.ok==true).length,tot=l.where((c)=>c.ok!=null).length;final pct=tot==0?0:pass*100/tot;
    final gr=pct>=85?'A - Strong':pct>=70?'B - Good':pct>=55?'C - Weak, use a small size':'D - Skip this trade';
    return [Glass(Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
      const Text('EXPERT CHECKLIST (done by the app)',style:TextStyle(color:kG3,fontSize:12)),
      Text('Grade $gr',style:TextStyle(fontSize:22,fontWeight:FontWeight.w800,color:pct>=70?gn:pct>=55?kAmber:rd)),
      Text('$pass of $tot checks passed',style:const TextStyle(color:kG2)),const Divider(height:20),
      for(final c in l)Padding(padding:const EdgeInsets.symmetric(vertical:4),child:Row(crossAxisAlignment:CrossAxisAlignment.start,children:[
        Text(c.ok==null?'-  ':(c.ok==true?'OK  ':'NO  '),style:TextStyle(fontWeight:FontWeight.w800,color:c.ok==null?kG3:(c.ok==true?gn:rd))),
        Expanded(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text(c.t),Text(c.why,style:const TextStyle(color:kG3,fontSize:12))]))]))]))];}
  List<Widget> panelCards(){final g=panel!;final ex=g.j['experts'];final v=g.str('panel_verdict').toUpperCase();
    return [Glass(Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
      const Text('EXPERT PANEL VERDICT',style:TextStyle(color:kG3,fontSize:12)),
      Text(v.isEmpty?'-':v,style:TextStyle(fontSize:26,fontWeight:FontWeight.w800,color:vcol(v))),
      Text('${g.num_('agree_count').round()} of ${ex is List?ex.length:4} experts agree with the trade',style:const TextStyle(color:kG2)),
      if(g.str('devils_advocate').isNotEmpty)Padding(padding:const EdgeInsets.only(top:8),child:Text('Opposite view: ${g.str('devils_advocate')}',style:const TextStyle(color:kAmber,fontSize:13))),
      for(final t in g.list('improvements'))Padding(padding:const EdgeInsets.only(top:4),child:Text('+ $t',style:const TextStyle(color:kG2,fontSize:13))),
      if(g.str('better_alternative').isNotEmpty&&g.str('better_alternative').toLowerCase()!='none')Padding(padding:const EdgeInsets.only(top:8),child:Text('Better option: ${g.str('better_alternative')}',style:const TextStyle(fontSize:13))),
      if(g.str('worst_case').isNotEmpty)Padding(padding:const EdgeInsets.only(top:8),child:Text('Worst case: ${g.str('worst_case')}',style:const TextStyle(color:kAmber,fontSize:13)))])),
      if(ex is List)for(final e in ex)if(e is Map)Glass(Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
        Row(mainAxisAlignment:MainAxisAlignment.spaceBetween,children:[Flexible(child:Text(sx(e['role']),style:const TextStyle(fontWeight:FontWeight.w700))),
          Text('${sx(e['verdict'])}  ${nm(e['score']).round()}/10',style:TextStyle(fontWeight:FontWeight.w700,color:vcol(sx(e['verdict']))))]),
        if(sx(e['point']).isNotEmpty)Padding(padding:const EdgeInsets.only(top:4),child:Text('+ ${sx(e['point'])}',style:const TextStyle(color:kG2,fontSize:13))),
        if(sx(e['concern']).isNotEmpty)Text('! ${sx(e['concern'])}',style:const TextStyle(color:kG3,fontSize:13))]))];}
  Widget sizeCard(){final x=r;final lot=panel?.num_('lot_size')??0;final cp=double.tryParse(capC.text)??0,rk=double.tryParse(rskC.text)??1;
    final ok=x!=null&&x.action.startsWith('BUY')&&x.entry>x.sl&&x.sl>0;
    return Glass(Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
      const Text('How many lots can I buy?',style:TextStyle(fontSize:18,fontWeight:FontWeight.w700)),const SizedBox(height:8),
      Row(children:[Expanded(child:tf('Your trading money (Rs)',capC)),const SizedBox(width:8),Expanded(child:tf('Risk per trade %',rskC))]),
      OutlinedButton(onPressed:()=>setState((){}),child:const Text('Calculate')),
      if(!ok)const Padding(padding:EdgeInsets.only(top:8),child:Text('Run the Auto tab and get a BUY trade first.',style:TextStyle(color:kG3)))
      else if(lot<=0)const Padding(padding:EdgeInsets.only(top:8),child:Text('Ask the expert panel first. It gives the current lot size.',style:TextStyle(color:kG3)))
      else ...[Builder(builder:(c){final y=x!;final unit=y.entry-y.sl,riskMoney=cp*rk/100;final byRisk=(riskMoney/(lot*unit)).floor(),byMoney=(cp/(y.entry*lot)).floor();final lots=byRisk<byMoney?byRisk:byMoney;
        return Column(children:[kv('Lot size',f0(lot)),kv('Money you are ready to lose','Rs ${f0(riskMoney)}'),kv('Cost of 1 lot','Rs ${f0(y.entry*lot)}'),
          if(lots<1)const Padding(padding:EdgeInsets.only(top:8),child:Text('Too small for even 1 lot at this risk. Skip, or choose a cheaper strike.',style:TextStyle(color:kAmber)))
          else ...[kv('Lots to buy','$lots'),kv('Money needed','Rs ${f0(lots*lot*y.entry)}'),kv('Loss if stop-loss hits','Rs ${f0(lots*lot*unit)}',rd),kv('Profit at target','Rs ${f0(lots*lot*(y.tgt-y.entry))}',gn)]]);})]]));}
  List<Widget> expert(){
    return [Glass(Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
      const Text('Expert window',style:TextStyle(fontSize:18,fontWeight:FontWeight.w700)),const SizedBox(height:4),
      const Text('1) A checklist the app does by itself.  2) A panel of 4 AI experts that review the trade.  3) How many lots fit your money.',style:TextStyle(color:kG2))])),
      ...chkCards(),
      if(panel==null)const Glass(Text('The expert panel comes from the same Gemini reply as your trade. Run the Auto tab and paste the reply there. The panel then appears here.',style:TextStyle(color:kG2))),
      if(panel!=null)...panelCards(),sizeCard()];}
  Widget appCard(){final x=r!;final buy=x.action.startsWith('BUY');
    return Glass(Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
      const Text('APP SUGGESTION (own calculation)',style:TextStyle(color:kG3,fontSize:12)),
      Text(x.action,style:TextStyle(fontSize:24,fontWeight:FontWeight.w800,color:x.score>=25?gn:x.score<=-25?rd:kAmber)),
      if(x.entry>0)Text(x.when,style:TextStyle(fontSize:17,fontWeight:FontWeight.w700,color:x.when.startsWith('WAIT')?kAmber:gn)),
      const Divider(height:20),
      kv('Market view','${x.bias}, score ${x.score.round()}'),kv('Confidence','${x.conv.round()}%'),kv('Search in broker app',x.legs),
      if(x.entry>0)...[kv(buy?'Buy price (about)':'Money you receive','Rs ${f2(x.entry)}'),
        if(buy&&x.when.startsWith('WAIT'))kv('Buy when index is near',f0(x.dipLevel)),
        kv('Stop-loss','Rs ${f2(x.sl)}',rd),kv('Take profit','Rs ${f2(x.tgt)}',gn),kv('Best time',x.timeWin),kv('Exit by',x.exitBy)],
      for(final n in x.notes.take(2))Padding(padding:const EdgeInsets.only(top:6),child:Text('- $n',style:const TextStyle(color:kAmber,fontSize:12)))]));}
  Widget gemCard(){final g=gem!;final a=g.action,go=a.contains('BUY');
    final lo=g.num_('entry_price_min'),hi=g.num_('entry_price_max');
    final col=a.contains('CALL')?gn:a.contains('PUT')?rd:kAmber;
    return Glass(Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
      const Text('GEMINI SUGGESTION (live web view)',style:TextStyle(color:kG3,fontSize:12)),
      Text(a.isEmpty?'-':a,style:TextStyle(fontSize:24,fontWeight:FontWeight.w800,color:col)),
      Text(g.timing,style:const TextStyle(fontSize:17,fontWeight:FontWeight.w700)),const Divider(height:20),
      kv('Market view',g.str('market_view')),kv('Confidence','${g.num_('confidence_pct').round()}%'),kv('Data time',g.str('data_time')),kv('Data quality',g.str('data_quality')),if(g.str('session_note').isNotEmpty)kv('Note',g.str('session_note')),
      if(go)...[kv('Search in broker app',g.str('instrument')),
        kv('Buy price','Rs ${lo.toStringAsFixed(0)} to ${(hi>lo?hi:lo).toStringAsFixed(0)}'),
        if(g.num_('index_entry_level')>0)kv('Buy when index is near',f0(g.num_('index_entry_level'))),
        kv('Stop-loss','Rs ${f0(g.num_('stop_loss'))}',rd),kv('Take profit 1','Rs ${f0(g.num_('target1'))}',gn),
        if(g.num_('target2')>0)kv('Take profit 2','Rs ${f0(g.num_('target2'))}',gn),
        kv('Support / resistance','${f0(g.num_('index_support'))} / ${f0(g.num_('index_resistance'))}'),
        kv('Best time to enter',g.str('best_time')),
        kv('Exit date and time',g.str('exit_date').isNotEmpty?'${g.str('exit_date')}, ${g.str('exit_time')}':g.str('exit_by')),
        if(g.num_('index_stop_level')>0)kv('Index level to exit (loss)',f0(g.num_('index_stop_level')),rd),
        if(g.num_('index_target_level')>0)kv('Index level to exit (profit)',f0(g.num_('index_target_level')),gn),
        if(g.str('exit_rule').isNotEmpty)kv('Exit rule',g.str('exit_rule'))],
      if(g.list('key_reasons').isNotEmpty)const Padding(padding:EdgeInsets.only(top:10),child:Text('Why',style:TextStyle(fontWeight:FontWeight.w700))),
      for(final t in g.list('key_reasons'))Text('+ $t',style:const TextStyle(color:kG2,fontSize:13)),
      if(g.list('risks').isNotEmpty||g.list('events').isNotEmpty)const Padding(padding:EdgeInsets.only(top:10),child:Text('Risks and events',style:TextStyle(fontWeight:FontWeight.w700))),
      for(final t in [...g.list('risks'),...g.list('events')])Text('! $t',style:const TextStyle(color:kG2,fontSize:13)),
      if(g.str('invalidate_if').isNotEmpty)Padding(padding:const EdgeInsets.only(top:10),child:Text('Cancel the trade if: ${g.str('invalidate_if')}',style:const TextStyle(color:kAmber,fontSize:13)))]));}
  Widget finalCard(){final f=decide(r!,gem!);final col=f.kind=='go'?gn:f.kind=='wait'?kAmber:rd;
    return Glass(Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
      const Text('FINAL DECISION (app + Gemini)',style:TextStyle(color:kG3,fontSize:12)),
      Text(f.title,style:TextStyle(fontSize:28,fontWeight:FontWeight.w800,color:col)),
      Text(f.sub,style:TextStyle(fontSize:18,fontWeight:FontWeight.w700,color:col)),const Divider(height:20),
      for(final e in f.rows)kv(e[0],e[1],e[0].startsWith('Exit if')?rd:e[0].startsWith('Take')?gn:null),
      const Padding(padding:EdgeInsets.only(top:10),child:Text('Learning tool, not SEBI-registered advice. Always use the stop-loss.',style:TextStyle(color:kG3,fontSize:11)))]));}
  Widget segStyle()=>SizedBox(width:double.infinity,child:CupertinoSlidingSegmentedControl<String>(groupValue:style,
    children:const{'Auto':Padding(padding:EdgeInsets.all(8),child:Text('Auto')),'Intraday':Padding(padding:EdgeInsets.all(8),child:Text('Intraday')),'Swing':Padding(padding:EdgeInsets.all(8),child:Text('2-Day'))},
    onValueChanged:(v)=>setState(()=>style=v!)));
  List<Widget> auto(){final p=autoPrompt(pick,style);
    return [calCard(),Glass(Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
      const Text('Nothing to type. Gemini finds all the data and makes the plan.',style:TextStyle(fontSize:16,fontWeight:FontWeight.w700)),
      const SizedBox(height:12),const Text('Which index?',style:TextStyle(color:kG2)),const SizedBox(height:6),
      SizedBox(width:double.infinity,child:CupertinoSlidingSegmentedControl<String>(groupValue:pick,
        children:const{'ANY':Padding(padding:EdgeInsets.all(6),child:Text('Best',style:TextStyle(fontSize:11))),'NIFTY':Padding(padding:EdgeInsets.all(6),child:Text('NIFTY',style:TextStyle(fontSize:11))),
          'BANKNIFTY':Padding(padding:EdgeInsets.all(6),child:Text('BANK',style:TextStyle(fontSize:11))),'FINNIFTY':Padding(padding:EdgeInsets.all(6),child:Text('FIN',style:TextStyle(fontSize:11))),
          'SENSEX':Padding(padding:EdgeInsets.all(6),child:Text('SENSEX',style:TextStyle(fontSize:11)))},onValueChanged:(v)=>setState(()=>pick=v!))),
      const SizedBox(height:12),const Text('Trading style',style:TextStyle(color:kG2)),const SizedBox(height:6),segStyle(),
      cap('Intraday = same day. 2-Day = hold up to 2 days. Auto = Gemini decides.'),
      const Text('Step 1',style:TextStyle(fontWeight:FontWeight.w700)),const Text('ONE question covers everything: live data, trade plan, exit plan, 3-day trend and the expert panel review. Tap Send in Gemini and wait (the Thinking / Pro model is best).',style:TextStyle(color:kG2)),
      const SizedBox(height:8),btn('Ask Gemini to do everything',()=>sendPrompt(p)),const SizedBox(height:14),
      const Text('Step 2',style:TextStyle(fontWeight:FontWeight.w700)),const Text('Tap the Copy icon under Gemini\'s reply, come back and tap below.',style:TextStyle(color:kG2)),
      const SizedBox(height:8),btn('Paste Gemini reply',()=>pasteReply(true)),const SizedBox(height:8),
      tf('Or paste the reply here',paste,lines:3),OutlinedButton(onPressed:()=>pasteReply(false),child:const Text('Read this reply')),
      if(gerr.isNotEmpty)Padding(padding:const EdgeInsets.only(top:8),child:Text(gerr,style:const TextStyle(color:kAmber,fontSize:13)))])),
      if(gem!=null)...[if(r!=null)appCard(),gemCard(),if(r!=null)finalCard()],
      Glass(Column(crossAxisAlignment:CrossAxisAlignment.start,children:[const Text('Backup',style:TextStyle(fontWeight:FontWeight.w700)),
        CupertinoButton(padding:EdgeInsets.zero,child:const Text('Copy the question only'),onPressed:()=>Clipboard.setData(ClipboardData(text:p)))]))];}

  void upd(void Function(GlassCfg) f){final n=cfg.value.copy();f(n);cfg.value=n;saveCfg(n);}
  Widget sl(String l,double v,double mn,double mx,void Function(double) f)=>Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
    Text('$l: ${v.toStringAsFixed(2)}',style:const TextStyle(color:kG2)),Slider(value:v.clamp(mn,mx).toDouble(),min:mn,max:mx,onChanged:f)]);
  Widget sw(int cur,void Function(int) f)=>Wrap(spacing:12,children:[for(final k in [0xFFFFFFFF,0xFF64D2FF,0xFF0A84FF,0xFFBF5AF2,0xFF30D158,0xFFFF375F,0xFFFF9F0A])
    GestureDetector(onTap:()=>f(k),child:Container(width:34,height:34,decoration:BoxDecoration(shape:BoxShape.circle,color:Color(k),border:Border.all(color:cur==k?kG2:Colors.black12,width:cur==k?3:1))))]);
  List<Widget> settings(){final g=cfg.value;
    Widget pre(String n,bool L,double b,double o,double bd,double r,double dp)=>ActionChip(label:Text(n),onPressed:()=>upd((x){x.light=L;x.blur=b;x.op=o;x.border=bd;x.radius=r;x.depth=dp;x.tint=0xFFFFFFFF;}));
    return [schedCard(),
      Glass(Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
        const Text('Theme',style:TextStyle(fontSize:18,fontWeight:FontWeight.w700)),const SizedBox(height:8),
        SizedBox(width:double.infinity,child:CupertinoSlidingSegmentedControl<bool>(groupValue:g.light,
          children:const{true:Padding(padding:EdgeInsets.all(8),child:Text('White glass')),false:Padding(padding:EdgeInsets.all(8),child:Text('Dark glass'))},
          onValueChanged:(v)=>upd((x){x.light=v!;if(v){x.op=.60;x.border=.95;x.blur=26;x.depth=.55;}else{x.op=.20;x.border=.22;x.blur=28;x.depth=.30;}x.tint=0xFFFFFFFF;}))),
        const SizedBox(height:12),const Text('Presets',style:TextStyle(fontWeight:FontWeight.w700)),const SizedBox(height:8),
        Wrap(spacing:8,children:[pre('OPPO Aqua',true,30,.60,.95,32,.55),pre('Clear white',true,16,.40,1.0,28,.40),pre('Milky white',true,40,.80,.90,30,.50),
          pre('Clear dark',false,10,.10,.35,26,.30),pre('Frosted dark',false,28,.20,.22,26,.30),pre('Ultra dark',false,50,.30,.18,34,.40)]),
        SwitchListTile(contentPadding:EdgeInsets.zero,title:const Text('Fluid moving background'),subtitle:const Text('Soft colour blobs drift slowly. Uses more battery.'),value:g.anim,onChanged:(v)=>upd((x)=>x.anim=v))])),
      Glass(Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
        sl('Blur',g.blur,0,60,(v)=>upd((x)=>x.blur=v)),sl('Glass opacity',g.op,.02,.9,(v)=>upd((x)=>x.op=v)),
        sl('Edge shine',g.border,0,1,(v)=>upd((x)=>x.border=v)),sl('Corner roundness',g.radius,8,40,(v)=>upd((x)=>x.radius=v)),sl('Depth (shadow)',g.depth,0,1,(v)=>upd((x)=>x.depth=v))])),
      Glass(Column(crossAxisAlignment:CrossAxisAlignment.start,children:[const Text('Glass tint'),const SizedBox(height:8),sw(g.tint,(k)=>upd((x)=>x.tint=k)),
        const SizedBox(height:16),const Text('Background colour glow'),const SizedBox(height:8),sw(g.accent,(k)=>upd((x)=>x.accent=k))])),
      btn('Reset to default',()=>upd((x){final d=GlassCfg();x.light=d.light;x.blur=d.blur;x.op=d.op;x.border=d.border;x.radius=d.radius;x.depth=d.depth;x.tint=d.tint;x.accent=d.accent;x.anim=d.anim;}))];}

  @override Widget build(BuildContext c){
    final pages=[auto,signal,forecast,expert,settings];
    final g=cfg.value;
    return AnnotatedRegion<SystemUiOverlayStyle>(value:g.light?SystemUiOverlayStyle.dark:SystemUiOverlayStyle.light,child:Scaffold(backgroundColor:g.light?Colors.white:const Color(0xFF05070F),extendBody:true,
      body:Stack(children:[Positioned.fill(child:bg(g)),
        SafeArea(child:ListView(padding:const EdgeInsets.fromLTRB(16,8,16,120),children:[const Text('IND AI Trade',style:TextStyle(fontSize:32,fontWeight:FontWeight.w800)),
          const SizedBox(height:12),...pages[t]()]))]),
      bottomNavigationBar:Padding(padding:const EdgeInsets.fromLTRB(20,0,20,20),child:Glass(Row(mainAxisAlignment:MainAxisAlignment.spaceEvenly,children:[
        nav(0,CupertinoIcons.bolt_fill,'Auto'),nav(1,CupertinoIcons.chart_bar_alt_fill,'Manual'),nav(2,CupertinoIcons.clock_fill,'2-Day'),nav(3,CupertinoIcons.star_fill,'Expert'),nav(4,CupertinoIcons.slider_horizontal_3,'Settings')]),p:const EdgeInsets.symmetric(vertical:8)))));
  }
}
