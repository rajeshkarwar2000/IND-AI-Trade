import 'dart:ui';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:android_intent_plus/android_intent.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'engine.dart';
import 'merge.dart';
import 'gemini.dart';

class GlassCfg{double blur=28,op=.20,border=.22,radius=26;int tint=0xFFFFFFFF,accent=0xFF0A84FF;
  GlassCfg copy()=>GlassCfg()..blur=blur..op=op..border=border..radius=radius..tint=tint..accent=accent;}
final cfg=ValueNotifier<GlassCfg>(GlassCfg());
Future<void> loadCfg()async{final p=await SharedPreferences.getInstance();final g=GlassCfg();
  g.blur=p.getDouble('blur')??g.blur;g.op=p.getDouble('op')??g.op;g.border=p.getDouble('border')??g.border;g.radius=p.getDouble('radius')??g.radius;
  g.tint=p.getInt('tint')??g.tint;g.accent=p.getInt('accent')??g.accent;cfg.value=g;}
Future<void> saveCfg(GlassCfg g)async{final p=await SharedPreferences.getInstance();
  await p.setDouble('blur',g.blur);await p.setDouble('op',g.op);await p.setDouble('border',g.border);await p.setDouble('radius',g.radius);
  await p.setInt('tint',g.tint);await p.setInt('accent',g.accent);}
void main()async{WidgetsFlutterBinding.ensureInitialized();await loadCfg();runApp(MaterialApp(debugShowCheckedModeBanner:false,title:'IND AI Trade',theme:ThemeData.dark(useMaterial3:true),home:const Home()));}

class Glass extends StatelessWidget{
  final Widget child;final EdgeInsets p;
  const Glass(this.child,{super.key,this.p=const EdgeInsets.all(16)});
  @override Widget build(BuildContext c)=>ValueListenableBuilder<GlassCfg>(valueListenable:cfg,builder:(c,g,_){final tint=Color(g.tint);
    return Padding(padding:const EdgeInsets.only(bottom:12),child:ClipRRect(borderRadius:BorderRadius.circular(g.radius),
      child:BackdropFilter(filter:ImageFilter.blur(sigmaX:g.blur+.01,sigmaY:g.blur+.01),child:Container(padding:p,decoration:BoxDecoration(borderRadius:BorderRadius.circular(g.radius),
        border:Border.all(color:Colors.white.withOpacity(g.border)),gradient:LinearGradient(begin:Alignment.topLeft,end:Alignment.bottomRight,
        colors:[tint.withOpacity(g.op),tint.withOpacity(g.op/4)])),child:child))));});
}

class Home extends StatefulWidget{const Home({super.key});@override State<Home> createState()=>_S();}
class _S extends State<Home>{
  int t=0;String ix='NIFTY',note='',ai='',style='Auto',pick='ANY';bool busy=false,simple=true;Res? r;Inp? inp;Gem? gem;String gerr='';DateTime expiry=DateTime.now().add(const Duration(days:3));
  final vix=TextEditingController(text:'14.5'),pcr=TextEditingController(text:'1.05'),oi=TextEditingController(text:'2'),
    spot=TextEditingController(),live=TextEditingController(),prevC=TextEditingController(),csv=TextEditingController(),paste=TextEditingController();
  static const gn=Color(0xFF30D158),rd=Color(0xFFFF453A),bl=Color(0xFF0A84FF);

  @override void initState(){super.initState();cfg.addListener(()=>setState((){}));}
  int days(){final n=DateTime.now();final d=DateTime(expiry.year,expiry.month,expiry.day).difference(DateTime(n.year,n.month,n.day)).inDays;return d<0?0:d;}
  Future<void> pickExpiry()async{final n=DateTime.now();final d=await showDatePicker(context:context,initialDate:expiry.isBefore(n)?n:expiry,firstDate:n.subtract(const Duration(days:1)),lastDate:n.add(const Duration(days:400)));if(d!=null)setState(()=>expiry=d);}
  Widget cap(String s)=>Padding(padding:const EdgeInsets.only(bottom:8),child:Text(s,style:const TextStyle(color:Colors.white38,fontSize:11)));
  void run(){final b=parseCsv(csv.text);final sp=double.tryParse(spot.text)??0;note='';
    if(sp<=0&&b.length<30){setState((){r=null;note='Please type the index price now (first box).';});return;}
    inp=Inp(ix:ix,style:style,vix:double.tryParse(vix.text)??15,pcr:double.tryParse(pcr.text)??1,oi:double.tryParse(oi.text)??0,spot:sp,live:double.tryParse(live.text)??0,
      prev:double.tryParse(prevC.text)??0,dte:days(),simple:simple,expiry:expiry,bars:b);
    r=analyze(inp!);setState((){});}

  Future<void> toGemini()async{final x=r;if(x==null)return;await sendPrompt(buildPrompt(inp!,x));}
  Future<void> sendPrompt(String p)async{
    await Clipboard.setData(ClipboardData(text:p));
    try{await AndroidIntent(action:'android.intent.action.SEND',package:'com.google.android.apps.bard',type:'text/plain',arguments:{'android.intent.extra.TEXT':p}).launch();}
    catch(_){try{await const AndroidIntent(action:'action_view',data:'https://gemini.google.com/app').launch();}catch(_){}}
    if(mounted)ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('Prompt copied. If the box is empty in Gemini, long-press and Paste.')));}
  Widget tf(String l,TextEditingController c,{int lines=1,bool hide=false})=>Padding(padding:const EdgeInsets.only(bottom:8),child:TextField(controller:c,maxLines:lines,obscureText:hide,
    keyboardType:lines>1||hide?TextInputType.multiline:const TextInputType.numberWithOptions(decimal:true),
    decoration:InputDecoration(labelText:l,filled:true,fillColor:Colors.white.withOpacity(.08),border:OutlineInputBorder(borderRadius:BorderRadius.circular(14),borderSide:BorderSide.none))));
  Widget kv(String k,String v,[Color? c])=>Padding(padding:const EdgeInsets.symmetric(vertical:3),child:Row(mainAxisAlignment:MainAxisAlignment.spaceBetween,
    children:[Flexible(child:Text(k,style:const TextStyle(color:Colors.white60))),const SizedBox(width:12),Flexible(child:Text(v,textAlign:TextAlign.right,style:TextStyle(fontWeight:FontWeight.w600,color:c)))]));
  Widget btn(String s,VoidCallback f)=>SizedBox(width:double.infinity,child:CupertinoButton.filled(onPressed:f,child:Text(s)));
  Widget blob(Color c)=>ImageFiltered(imageFilter:ImageFilter.blur(sigmaX:90,sigmaY:90),child:Container(width:280,height:280,decoration:BoxDecoration(shape:BoxShape.circle,color:c.withOpacity(.5))));
  Widget nav(int i,IconData ic,String l)=>GestureDetector(onTap:()=>setState(()=>t=i),child:Column(mainAxisSize:MainAxisSize.min,children:[
    Icon(ic,color:t==i?bl:Colors.white54),Text(l,style:TextStyle(fontSize:11,color:t==i?bl:Colors.white54))]));
  String dt(int n){var d=DateTime.now();for(var i=0;i<n;i++){do{d=d.add(const Duration(days:1));}while(d.weekday>5);}
    const m=['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];return '${d.day} ${m[d.month-1]}';}
  String f0(double x)=>x.toStringAsFixed(0);
  String f2(double x)=>x.toStringAsFixed(2);

  List<Widget> signal(){
    final w=<Widget>[Glass(Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
      SizedBox(width:double.infinity,child:CupertinoSlidingSegmentedControl<String>(groupValue:ix,
        children:{for(final k in steps.keys)k:Padding(padding:const EdgeInsets.all(6),child:Text(k,style:const TextStyle(fontSize:11)))},onValueChanged:(v)=>setState(()=>ix=v!))),
      const SizedBox(height:10),const Text('Trading style',style:TextStyle(color:Colors.white70)),const SizedBox(height:6),
      SizedBox(width:double.infinity,child:CupertinoSlidingSegmentedControl<String>(groupValue:style,
        children:const{'Auto':Padding(padding:EdgeInsets.all(8),child:Text('Auto')),'Intraday':Padding(padding:EdgeInsets.all(8),child:Text('Intraday')),'Swing':Padding(padding:EdgeInsets.all(8),child:Text('2-Day'))},
        onValueChanged:(v)=>setState(()=>style=v!))),
      cap('Intraday = buy and sell the same day. 2-Day = hold up to 2 days. Auto = app decides.'),
      SwitchListTile(contentPadding:EdgeInsets.zero,title:const Text('Beginner mode (only buy CALL / PUT)'),value:simple,onChanged:(v)=>setState(()=>simple=v)),
      Row(children:[Expanded(child:tf('Index price now (Spot)',spot)),const SizedBox(width:8),Expanded(child:tf('Yesterday close',prevC))]),
      Row(children:[Expanded(child:tf('Fear meter (India VIX)',vix)),const SizedBox(width:8),Expanded(child:tf('Put/Call ratio (PCR)',pcr))]),
      Row(children:[Expanded(child:tf('Futures OI change %',oi)),const SizedBox(width:8),Expanded(child:tf('Live option price (optional)',live))]),
      cap('VIX above 16 = options are costly. PCR above 1 = slightly bullish. OI change = more positions opened today (+) or closed (-). Live option price = the price you see in your broker app for the strike below.'),
      OutlinedButton(onPressed:pickExpiry,child:Text('Expiry date: ${fd(expiry)}  (${days()} days left) - tap to change')),
      const SizedBox(height:8),tf('Optional: paste daily history  o,h,l,c,v  (30+ rows)',csv,lines:2),btn('Analyze',run)]))];
    if(note.isNotEmpty)w.add(Text(note,style:const TextStyle(color:Colors.amber,fontSize:13)));
    final x=r;if(x==null)return w;
    final col=x.score>=25?gn:x.score<=-25?rd:Colors.amber,buy=x.action.startsWith('BUY'),trade=x.entry>0;
    w.add(Glass(Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
      Text(x.action,style:TextStyle(fontSize:26,fontWeight:FontWeight.w800,color:col)),
      Text(x.plain,style:const TextStyle(color:Colors.white70)),const SizedBox(height:8),
      if(trade)Text(x.when,style:TextStyle(fontSize:20,fontWeight:FontWeight.w700,color:x.when.startsWith('WAIT')?Colors.amber:gn)),
      const Divider(height:20),
      kv('Date and time now','${fd(DateTime.now())}, ${TimeOfDay.now().format(context)}'),
      kv('Instrument','Index Option (OPTIDX)'),kv('Search in broker app',x.legs),kv('Trading style',x.style),
      kv('Market view','${x.bias}, score ${x.score.round()}'),kv('Confidence','${x.conv.round()}%'),
      if(trade)...[
        kv(buy?'Buy price (about)':'Money you receive','Rs ${f2(x.entry)}'),
        if(buy)kv('Do not pay above','Rs ${f2(x.maxBuy)}'),
        if(buy&&x.when.startsWith('WAIT'))kv('Buy when index is near',f0(x.dipLevel)),
        kv(buy?'Exit if price falls to (stop-loss)':'Exit if loss reaches','Rs ${f2(x.sl)}',rd),
        kv(buy?'Take profit at':'Close when price drops to','Rs ${f2(x.tgt)}',gn),
        if(buy)kv('Loss per unit if stop-loss hits','Rs ${f2(x.entry-x.sl)}'),
        kv('Best time to enter',x.timeWin),kv('Exit by',x.exitBy)],
      if(buy)...[kv('Option moves per 1 index point','Rs ${f2(x.delta.abs())}'),kv('Time loss per day','Rs ${f2(x.theta.abs())}')],
      kv('Index price',f2(x.spot)),kv('Normal daily move',f0(x.atr)+' points'),
      for(final n in x.notes)Padding(padding:const EdgeInsets.only(top:6),child:Text('- $n',style:const TextStyle(color:Colors.white60,fontSize:12)))])));
    w.add(Glass(Column(children:[const Align(alignment:Alignment.centerLeft,child:Text('Why? (plus = up, minus = down)',style:TextStyle(fontWeight:FontWeight.w700))),
      for(final e in x.parts.entries)kv(e.key,(e.value>0?'+':'')+f0(e.value),e.value>0?gn:e.value<0?rd:null)])));
    w.add(btn('Send to Gemini app',toGemini));
    w.add(const Padding(padding:EdgeInsets.only(top:8),child:Text('Learning tool, not SEBI-registered advice. Options can lose all money.',style:TextStyle(color:Colors.white38,fontSize:11))));
    return w;
  }
  List<Widget> forecast()=>[...forecast0(),...gemDays()];
  List<Widget> gemDays(){final g=gem;if(g==null)return [];
    return [for(final k in ['day1','day2'])Glass(Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
      Text('Gemini view: ${k=='day1'?'Next trading day':'Day after'}',style:const TextStyle(fontSize:16,fontWeight:FontWeight.w700)),
      kv('Likely range','${f0(g.d(k,'low'))} to ${f0(g.d(k,'high'))}'),kv('Direction',g.ds(k,'bias')),
      kv('UP / DOWN / FLAT','${f0(g.d(k,'up_pct'))}% / ${f0(g.d(k,'down_pct'))}% / ${f0(g.d(k,'flat_pct'))}%')]))];}
  List<Widget> forecast0(){final x=r;if(x==null)return [const Glass(Text('Run the Auto tab first.'))];
    return [for(var i=0;i<2;i++)Glass(Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
      Text(i==0?'App view: next trading day (${dt(1)})':'App view: day after (${dt(2)})',style:const TextStyle(fontSize:18,fontWeight:FontWeight.w700)),const SizedBox(height:6),
      kv('Likely range','${f0(x.days[i][0])} to ${f0(x.days[i][2])}'),kv('Best guess',f0(x.days[i][1]))])),
      Glass(Column(children:[kv('Chance market goes UP','${(x.pUp*100).round()}%',gn),kv('Chance market goes DOWN','${(x.pDn*100).round()}%',rd),kv('Chance it stays flat','${(x.pFlat*100).round()}%'),
      const SizedBox(height:6),const Text('Rough estimate from the fear meter (VIX) and today\'s score. Holidays are not counted.',style:TextStyle(color:Colors.white38,fontSize:11))]))];}
  Future<void> pasteReply(bool clip)async{var t=paste.text;
    if(clip){final d=await Clipboard.getData('text/plain');t=d?.text??'';paste.text=t;}
    final g=parseGem(t);(Inp,Res)? er;if(g!=null)er=engineFromGem(g,style,simple);
    setState((){gem=g;inp=er?.$1;r=er?.$2;gerr=g==null?'Could not read the reply. Copy the full Gemini reply. It starts with { and ends with }. If Gemini wrote normal text, ask it: "Give only the JSON".':'';});}
  Widget appCard(){final x=r!;final buy=x.action.startsWith('BUY');
    return Glass(Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
      const Text('APP SUGGESTION (own calculation)',style:TextStyle(color:Colors.white54,fontSize:12)),
      Text(x.action,style:TextStyle(fontSize:24,fontWeight:FontWeight.w800,color:x.score>=25?gn:x.score<=-25?rd:Colors.amber)),
      if(x.entry>0)Text(x.when,style:TextStyle(fontSize:17,fontWeight:FontWeight.w700,color:x.when.startsWith('WAIT')?Colors.amber:gn)),
      const Divider(height:20),
      kv('Market view','${x.bias}, score ${x.score.round()}'),kv('Confidence','${x.conv.round()}%'),kv('Search in broker app',x.legs),
      if(x.entry>0)...[kv(buy?'Buy price (about)':'Money you receive','Rs ${f2(x.entry)}'),
        if(buy&&x.when.startsWith('WAIT'))kv('Buy when index is near',f0(x.dipLevel)),
        kv('Stop-loss','Rs ${f2(x.sl)}',rd),kv('Take profit','Rs ${f2(x.tgt)}',gn),kv('Best time',x.timeWin),kv('Exit by',x.exitBy)]]));}
  Widget gemCard(){final g=gem!;final a=g.action,go=a.contains('BUY');
    final lo=g.num_('entry_price_min'),hi=g.num_('entry_price_max');
    final col=a.contains('CALL')?gn:a.contains('PUT')?rd:Colors.amber;
    return Glass(Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
      const Text('GEMINI SUGGESTION (live web view)',style:TextStyle(color:Colors.white54,fontSize:12)),
      Text(a.isEmpty?'-':a,style:TextStyle(fontSize:24,fontWeight:FontWeight.w800,color:col)),
      Text(g.timing,style:const TextStyle(fontSize:17,fontWeight:FontWeight.w700)),const Divider(height:20),
      kv('Market view',g.str('market_view')),kv('Confidence','${g.num_('confidence_pct').round()}%'),kv('Data time',g.str('data_time')),kv('Data quality',g.str('data_quality')),if(g.str('session_note').isNotEmpty)kv('Note',g.str('session_note')),
      if(go)...[kv('Search in broker app',g.str('instrument')),
        kv('Buy price','Rs ${lo.toStringAsFixed(0)} to ${(hi>lo?hi:lo).toStringAsFixed(0)}'),
        if(g.num_('index_entry_level')>0)kv('Buy when index is near',f0(g.num_('index_entry_level'))),
        kv('Stop-loss','Rs ${f0(g.num_('stop_loss'))}',rd),kv('Take profit 1','Rs ${f0(g.num_('target1'))}',gn),
        if(g.num_('target2')>0)kv('Take profit 2','Rs ${f0(g.num_('target2'))}',gn),
        kv('Support / resistance','${f0(g.num_('index_support'))} / ${f0(g.num_('index_resistance'))}'),
        kv('Best time to enter',g.str('best_time')),
        kv('Exit date and time',g.str('exit_date').isNotEmpty?'${g.str('exit_date')}, ${g.str('exit_time')}':g.str('exit_by')),
        if(g.num_('index_stop_level')>0)kv('Index level to exit (loss)',f0(g.num_('index_stop_level')),rd),
        if(g.num_('index_target_level')>0)kv('Index level to exit (profit)',f0(g.num_('index_target_level')),gn),
        if(g.str('exit_rule').isNotEmpty)kv('Exit rule',g.str('exit_rule'))],
      if(g.list('key_reasons').isNotEmpty)const Padding(padding:EdgeInsets.only(top:10),child:Text('Why',style:TextStyle(fontWeight:FontWeight.w700))),
      for(final t in g.list('key_reasons'))Text('+ $t',style:const TextStyle(color:Colors.white70,fontSize:13)),
      if(g.list('risks').isNotEmpty||g.list('events').isNotEmpty)const Padding(padding:EdgeInsets.only(top:10),child:Text('Risks and events',style:TextStyle(fontWeight:FontWeight.w700))),
      for(final t in [...g.list('risks'),...g.list('events')])Text('! $t',style:const TextStyle(color:Colors.white70,fontSize:13)),
      if(g.str('invalidate_if').isNotEmpty)Padding(padding:const EdgeInsets.only(top:10),child:Text('Cancel the trade if: ${g.str('invalidate_if')}',style:const TextStyle(color:Colors.amber,fontSize:13)))]));}
  Widget finalCard(){final f=decide(r!,gem!);final col=f.kind=='go'?gn:f.kind=='wait'?Colors.amber:rd;
    return Glass(Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
      const Text('FINAL DECISION (app + Gemini)',style:TextStyle(color:Colors.white54,fontSize:12)),
      Text(f.title,style:TextStyle(fontSize:28,fontWeight:FontWeight.w800,color:col)),
      Text(f.sub,style:TextStyle(fontSize:18,fontWeight:FontWeight.w700,color:col)),const Divider(height:20),
      for(final e in f.rows)kv(e[0],e[1],e[0].startsWith('Exit if')?rd:e[0].startsWith('Take')?gn:null),
      const Padding(padding:EdgeInsets.only(top:10),child:Text('Learning tool, not SEBI-registered advice. Always use the stop-loss.',style:TextStyle(color:Colors.white38,fontSize:11)))]));}
  Widget segStyle()=>SizedBox(width:double.infinity,child:CupertinoSlidingSegmentedControl<String>(groupValue:style,
    children:const{'Auto':Padding(padding:EdgeInsets.all(8),child:Text('Auto')),'Intraday':Padding(padding:EdgeInsets.all(8),child:Text('Intraday')),'Swing':Padding(padding:EdgeInsets.all(8),child:Text('2-Day'))},
    onValueChanged:(v)=>setState(()=>style=v!)));
  List<Widget> auto(){final p=autoPrompt(pick,style);
    return [Glass(Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
      const Text('Nothing to type. Gemini finds all the data and makes the plan.',style:TextStyle(fontSize:16,fontWeight:FontWeight.w700)),
      const SizedBox(height:12),const Text('Which index?',style:TextStyle(color:Colors.white70)),const SizedBox(height:6),
      SizedBox(width:double.infinity,child:CupertinoSlidingSegmentedControl<String>(groupValue:pick,
        children:const{'ANY':Padding(padding:EdgeInsets.all(6),child:Text('Best',style:TextStyle(fontSize:11))),'NIFTY':Padding(padding:EdgeInsets.all(6),child:Text('NIFTY',style:TextStyle(fontSize:11))),
          'BANKNIFTY':Padding(padding:EdgeInsets.all(6),child:Text('BANK',style:TextStyle(fontSize:11))),'FINNIFTY':Padding(padding:EdgeInsets.all(6),child:Text('FIN',style:TextStyle(fontSize:11))),
          'SENSEX':Padding(padding:EdgeInsets.all(6),child:Text('SENSEX',style:TextStyle(fontSize:11)))},onValueChanged:(v)=>setState(()=>pick=v!))),
      const SizedBox(height:12),const Text('Trading style',style:TextStyle(color:Colors.white70)),const SizedBox(height:6),segStyle(),
      cap('Intraday = same day. 2-Day = hold up to 2 days. Auto = Gemini decides.'),
      const Text('Step 1',style:TextStyle(fontWeight:FontWeight.w700)),const Text('Gemini opens with the full question. Tap Send there and wait for the reply (use the Thinking / Pro model for best results).',style:TextStyle(color:Colors.white70)),
      const SizedBox(height:8),btn('Ask Gemini to do everything',()=>sendPrompt(p)),const SizedBox(height:14),
      const Text('Step 2',style:TextStyle(fontWeight:FontWeight.w700)),const Text('Tap the Copy icon under Gemini\'s reply, come back and tap below.',style:TextStyle(color:Colors.white70)),
      const SizedBox(height:8),btn('Paste Gemini reply',()=>pasteReply(true)),const SizedBox(height:8),
      tf('Or paste the reply here',paste,lines:3),OutlinedButton(onPressed:()=>pasteReply(false),child:const Text('Read this reply')),
      if(gerr.isNotEmpty)Padding(padding:const EdgeInsets.only(top:8),child:Text(gerr,style:const TextStyle(color:Colors.amber,fontSize:13)))])),
      if(gem!=null)...[if(r!=null)appCard(),gemCard(),if(r!=null)finalCard()],
      Glass(Column(crossAxisAlignment:CrossAxisAlignment.start,children:[const Text('Backup',style:TextStyle(fontWeight:FontWeight.w700)),
        CupertinoButton(padding:EdgeInsets.zero,child:const Text('Copy the question only'),onPressed:()=>Clipboard.setData(ClipboardData(text:p)))]))];}

  void upd(void Function(GlassCfg) f){final n=cfg.value.copy();f(n);cfg.value=n;saveCfg(n);}
  Widget sl(String l,double v,double mn,double mx,void Function(double) f)=>Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
    Text('$l: ${v.toStringAsFixed(2)}',style:const TextStyle(color:Colors.white70)),Slider(value:v.clamp(mn,mx).toDouble(),min:mn,max:mx,onChanged:f)]);
  Widget sw(int cur,void Function(int) f)=>Wrap(spacing:12,children:[for(final k in [0xFFFFFFFF,0xFF64D2FF,0xFF0A84FF,0xFFBF5AF2,0xFF30D158,0xFFFF375F,0xFFFF9F0A])
    GestureDetector(onTap:()=>f(k),child:Container(width:34,height:34,decoration:BoxDecoration(shape:BoxShape.circle,color:Color(k),border:Border.all(color:cur==k?Colors.white:Colors.white24,width:cur==k?3:1))))]);
  List<Widget> settings(){final g=cfg.value;
    Widget pre(String n,double b,double o,double bd,double r)=>ActionChip(label:Text(n),onPressed:()=>upd((x){x.blur=b;x.op=o;x.border=bd;x.radius=r;}));
    return [Glass(Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
      const Text('Glass presets',style:TextStyle(fontSize:18,fontWeight:FontWeight.w700)),const SizedBox(height:8),
      Wrap(spacing:8,children:[pre('Clear',10,.10,.35,26),pre('Frosted',28,.20,.22,26),pre('Ultra',50,.30,.18,34),pre('Subtle',20,.06,.15,18),pre('Solid',60,.45,.30,22)])])),
      Glass(Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
        sl('Blur',g.blur,0,60,(v)=>upd((x)=>x.blur=v)),sl('Glass opacity',g.op,.02,.6,(v)=>upd((x)=>x.op=v)),
        sl('Border brightness',g.border,0,.6,(v)=>upd((x)=>x.border=v)),sl('Corner radius',g.radius,8,40,(v)=>upd((x)=>x.radius=v))])),
      Glass(Column(crossAxisAlignment:CrossAxisAlignment.start,children:[const Text('Glass tint'),const SizedBox(height:8),sw(g.tint,(k)=>upd((x)=>x.tint=k)),
        const SizedBox(height:16),const Text('Background glow'),const SizedBox(height:8),sw(g.accent,(k)=>upd((x)=>x.accent=k))])),
      btn('Reset to default',()=>upd((x){final d=GlassCfg();x.blur=d.blur;x.op=d.op;x.border=d.border;x.radius=d.radius;x.tint=d.tint;x.accent=d.accent;}))];}

  @override Widget build(BuildContext c){
    final pages=[auto,signal,forecast,settings];
    return Scaffold(backgroundColor:const Color(0xFF05070F),extendBody:true,
      body:Stack(children:[Positioned(top:-90,left:-80,child:blob(Color(cfg.value.accent))),Positioned(bottom:100,right:-100,child:blob(const Color(0xFFBF5AF2))),
        SafeArea(child:ListView(padding:const EdgeInsets.fromLTRB(16,8,16,120),children:[const Text('IND AI Trade',style:TextStyle(fontSize:32,fontWeight:FontWeight.w800)),
          const SizedBox(height:12),...pages[t]()]))]),
      bottomNavigationBar:Padding(padding:const EdgeInsets.fromLTRB(20,0,20,20),child:Glass(Row(mainAxisAlignment:MainAxisAlignment.spaceEvenly,children:[
        nav(0,CupertinoIcons.bolt_fill,'Auto'),nav(1,CupertinoIcons.chart_bar_alt_fill,'Manual'),nav(2,CupertinoIcons.clock_fill,'2-Day'),nav(3,CupertinoIcons.slider_horizontal_3,'Glass')]),p:const EdgeInsets.symmetric(vertical:8))));
  }
}
