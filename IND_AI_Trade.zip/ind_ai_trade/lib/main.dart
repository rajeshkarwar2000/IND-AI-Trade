import 'dart:ui';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:android_intent_plus/android_intent.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'engine.dart';
import 'gemini.dart';

class GlassCfg{double blur=28,op=.20,border=.22,radius=26;int tint=0xFFFFFFFF,accent=0xFF0A84FF;
  GlassCfg copy()=>GlassCfg()..blur=blur..op=op..border=border..radius=radius..tint=tint..accent=accent;}
final cfg=ValueNotifier<GlassCfg>(GlassCfg());
Future<void> loadCfg()async{final p=await SharedPreferences.getInstance();final g=GlassCfg();
  g.blur=p.getDouble('blur')??g.blur;g.op=p.getDouble('op')??g.op;g.border=p.getDouble('border')??g.border;g.radius=p.getDouble('radius')??g.radius;
  g.tint=p.getInt('tint')??g.tint;g.accent=p.getInt('accent')??g.accent;cfg.value=g;}
Future<void> saveCfg(GlassCfg g)async{final p=await SharedPreferences.getInstance();
  await p.setDouble('blur',g.blur);await p.setDouble('op',g.op);await p.setDouble('border',g.border);await p.setDouble('radius',g.radius);
  await p.setInt('tint',g.tint);await p.setInt('accent',g.accent);}
void main()async{WidgetsFlutterBinding.ensureInitialized();await loadCfg();runApp(MaterialApp(debugShowCheckedModeBanner:false,title:'IND AI Trade',theme:ThemeData.dark(useMaterial3:true),home:const Home()));}

class Glass extends StatelessWidget{
  final Widget child;final EdgeInsets p;
  const Glass(this.child,{super.key,this.p=const EdgeInsets.all(16)});
  @override Widget build(BuildContext c)=>ValueListenableBuilder<GlassCfg>(valueListenable:cfg,builder:(c,g,_){final tint=Color(g.tint);
    return Padding(padding:const EdgeInsets.only(bottom:12),child:ClipRRect(borderRadius:BorderRadius.circular(g.radius),
      child:BackdropFilter(filter:ImageFilter.blur(sigmaX:g.blur+.01,sigmaY:g.blur+.01),child:Container(padding:p,decoration:BoxDecoration(borderRadius:BorderRadius.circular(g.radius),
        border:Border.all(color:Colors.white.withOpacity(g.border)),gradient:LinearGradient(begin:Alignment.topLeft,end:Alignment.bottomRight,
        colors:[tint.withOpacity(g.op),tint.withOpacity(g.op/4)])),child:child))));});
}

class Home extends StatefulWidget{const Home({super.key});@override State<Home> createState()=>_S();}
class _S extends State<Home>{
  int t=0;String ix='NIFTY',note='',ai='';bool busy=false;Res? r;Inp? inp;
  final vix=TextEditingController(text:'14.5'),pcr=TextEditingController(text:'1.05'),oi=TextEditingController(text:'2'),
    dte=TextEditingController(text:'4'),csv=TextEditingController(),key=TextEditingController();
  static const gn=Color(0xFF30D158),rd=Color(0xFFFF453A),bl=Color(0xFF0A84FF);

  @override void initState(){super.initState();cfg.addListener(()=>setState((){}));}
  void run(){var b=parseCsv(csv.text);note='';
    if(b.length<30){b=demo(ix);note='Demo data in use. Paste real daily OHLCV rows for live analysis.';}
    inp=Inp(ix,double.tryParse(vix.text)??15,double.tryParse(pcr.text)??1,double.tryParse(oi.text)??0,int.tryParse(dte.text)??4,b);
    r=analyze(inp!);setState((){});}

  Future<void> toGemini()async{final x=r;if(x==null)return;final p=buildPrompt(inp!,x);
    await Clipboard.setData(ClipboardData(text:p));
    try{await AndroidIntent(action:'android.intent.action.SEND',package:'com.google.android.apps.bard',type:'text/plain',arguments:{'android.intent.extra.TEXT':p}).launch();}
    catch(_){try{await const AndroidIntent(action:'action_view',data:'https://gemini.google.com/app').launch();}catch(_){}}
    if(mounted)ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('Prompt copied. If the box is empty in Gemini, long-press and Paste.')));}
  Widget tf(String l,TextEditingController c,{int lines=1,bool hide=false})=>Padding(padding:const EdgeInsets.only(bottom:8),child:TextField(controller:c,maxLines:lines,obscureText:hide,
    keyboardType:lines>1||hide?TextInputType.multiline:const TextInputType.numberWithOptions(decimal:true),
    decoration:InputDecoration(labelText:l,filled:true,fillColor:Colors.white.withOpacity(.08),border:OutlineInputBorder(borderRadius:BorderRadius.circular(14),borderSide:BorderSide.none))));
  Widget kv(String k,String v,[Color? c])=>Padding(padding:const EdgeInsets.symmetric(vertical:3),child:Row(mainAxisAlignment:MainAxisAlignment.spaceBetween,
    children:[Flexible(child:Text(k,style:const TextStyle(color:Colors.white60))),const SizedBox(width:12),Flexible(child:Text(v,textAlign:TextAlign.right,style:TextStyle(fontWeight:FontWeight.w600,color:c)))]));
  Widget btn(String s,VoidCallback f)=>SizedBox(width:double.infinity,child:CupertinoButton.filled(onPressed:f,child:Text(s)));
  Widget blob(Color c)=>ImageFiltered(imageFilter:ImageFilter.blur(sigmaX:90,sigmaY:90),child:Container(width:280,height:280,decoration:BoxDecoration(shape:BoxShape.circle,color:c.withOpacity(.5))));
  Widget nav(int i,IconData ic,String l)=>GestureDetector(onTap:()=>setState(()=>t=i),child:Column(mainAxisSize:MainAxisSize.min,children:[
    Icon(ic,color:t==i?bl:Colors.white54),Text(l,style:TextStyle(fontSize:11,color:t==i?bl:Colors.white54))]));
  String dt(int n){var d=DateTime.now();for(var i=0;i<n;i++){do{d=d.add(const Duration(days:1));}while(d.weekday>5);}
    const m=['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];return '${d.day} ${m[d.month-1]}';}
  String f0(double x)=>x.toStringAsFixed(0),f2(double x)=>x.toStringAsFixed(2);

  List<Widget> signal(){
    final w=<Widget>[Glass(Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
      SizedBox(width:double.infinity,child:CupertinoSlidingSegmentedControl<String>(groupValue:ix,
        children:{for(final k in steps.keys)k:Padding(padding:const EdgeInsets.all(6),child:Text(k,style:const TextStyle(fontSize:11)))},onValueChanged:(v)=>setState(()=>ix=v!))),
      const SizedBox(height:12),
      Row(children:[Expanded(child:tf('India VIX',vix)),const SizedBox(width:8),Expanded(child:tf('PCR',pcr))]),
      Row(children:[Expanded(child:tf('Fut OI chg %',oi)),const SizedBox(width:8),Expanded(child:tf('Days to expiry',dte))]),
      tf('Daily OHLCV rows: o,h,l,c,v (30+)',csv,lines:3),btn('Analyze',run)]))];
    final x=r;if(x==null)return w;
    final col=x.score>=25?gn:x.score<=-25?rd:Colors.amber;
    w.add(Glass(Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
      Text(x.action,style:TextStyle(fontSize:26,fontWeight:FontWeight.w800,color:col)),
      Text('${x.bias} | conviction ${x.conv.round()}% | score ${x.score.round()}',style:const TextStyle(color:Colors.white70)),
      const SizedBox(height:8),Text(x.legs,style:const TextStyle(fontSize:15)),const Divider(height:20),
      if(x.entry>0)...[kv(x.action.startsWith('BUY')?'Entry premium':'Net credit',f2(x.entry)),kv('Stop-loss',f2(x.sl),rd),kv('Target',f2(x.tgt),gn)],
      if(x.delta!=0)...[kv('Delta',f2(x.delta)),kv('Theta / day',f2(x.theta))],
      kv('Instrument','${inp!.ix} OPTIDX | ATM ${x.atm} | ${inp!.dte}d to expiry'),kv('Spot',f2(x.spot)),
      kv('ATR14 | RSI14','${f0(x.atr)} | ${f0(x.rsi)}'),kv('IV (VIX proxy)','${f2(x.iv*100)}%')])));
    w.add(Glass(Column(children:[for(final e in x.parts.entries)kv(e.key,(e.value>0?'+':'')+f0(e.value),e.value>0?gn:e.value<0?rd:null)])));
    w.add(btn('Send to Gemini app',toGemini));
    if(note.isNotEmpty)w.add(Text(note,style:const TextStyle(color:Colors.amber,fontSize:12)));
    w.add(const Text('Educational tool, not SEBI-registered advice. Options trading carries substantial risk.',style:TextStyle(color:Colors.white38,fontSize:11)));
    return w;
  }
  List<Widget> forecast(){final x=r;if(x==null)return [const Glass(Text('Run Analyze on the Signal tab first.'))];
    return [for(var i=0;i<2;i++)Glass(Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
      Text('Day +${i+1} (${dt(i+1)})',style:const TextStyle(fontSize:18,fontWeight:FontWeight.w700)),const SizedBox(height:6),
      kv('Expected range (1 sigma)','${f0(x.days[i][0])} - ${f0(x.days[i][2])}'),kv('Drift-adjusted mid',f0(x.days[i][1]))])),
      Glass(Column(children:[kv('Bullish probability','${(x.pUp*100).round()}%',gn),kv('Bearish probability','${(x.pDn*100).round()}%',rd),kv('Range-bound','${(x.pFlat*100).round()}%'),
      const SizedBox(height:6),const Text('Model: IV-scaled 1-sigma move x composite-score drift; sigmoid probabilities. Holidays not accounted.',style:TextStyle(color:Colors.white38,fontSize:11))]))];}
  List<Widget> gemini(){final x=r;if(x==null)return [const Glass(Text('Run Analyze on the Signal tab first.'))];
    final p=buildPrompt(inp!,x);
    return [btn('Send to Gemini app (copy + open)',toGemini),const SizedBox(height:12),Glass(Column(children:[tf('Gemini API key (aistudio.google.com)',key,hide:true),btn('Ask Gemini (live web search)',()async{
      setState((){busy=true;ai='';});final a=await askGemini(key.text.trim(),p);setState((){busy=false;ai=a;});}),
      CupertinoButton(child:const Text('Copy prompt'),onPressed:()=>Clipboard.setData(ClipboardData(text:p)))])),
      if(busy)const Center(child:CupertinoActivityIndicator()),if(ai.isNotEmpty)Glass(SelectableText(ai)),Glass(SelectableText(p,style:const TextStyle(fontSize:11,color:Colors.white60)))];}

  void upd(void Function(GlassCfg) f){final n=cfg.value.copy();f(n);cfg.value=n;saveCfg(n);}
  Widget sl(String l,double v,double mn,double mx,void Function(double) f)=>Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
    Text('$l: ${v.toStringAsFixed(2)}',style:const TextStyle(color:Colors.white70)),Slider(value:v.clamp(mn,mx).toDouble(),min:mn,max:mx,onChanged:f)]);
  Widget sw(int cur,void Function(int) f)=>Wrap(spacing:12,children:[for(final k in [0xFFFFFFFF,0xFF64D2FF,0xFF0A84FF,0xFFBF5AF2,0xFF30D158,0xFFFF375F,0xFFFF9F0A])
    GestureDetector(onTap:()=>f(k),child:Container(width:34,height:34,decoration:BoxDecoration(shape:BoxShape.circle,color:Color(k),border:Border.all(color:cur==k?Colors.white:Colors.white24,width:cur==k?3:1))))]);
  List<Widget> settings(){final g=cfg.value;
    Widget pre(String n,double b,double o,double bd,double r)=>ActionChip(label:Text(n),onPressed:()=>upd((x){x.blur=b;x.op=o;x.border=bd;x.radius=r;}));
    return [Glass(Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
      const Text('Glass presets',style:TextStyle(fontSize:18,fontWeight:FontWeight.w700)),const SizedBox(height:8),
      Wrap(spacing:8,children:[pre('Clear',10,.10,.35,26),pre('Frosted',28,.20,.22,26),pre('Ultra',50,.30,.18,34),pre('Subtle',20,.06,.15,18),pre('Solid',60,.45,.30,22)])])),
      Glass(Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
        sl('Blur',g.blur,0,60,(v)=>upd((x)=>x.blur=v)),sl('Glass opacity',g.op,.02,.6,(v)=>upd((x)=>x.op=v)),
        sl('Border brightness',g.border,0,.6,(v)=>upd((x)=>x.border=v)),sl('Corner radius',g.radius,8,40,(v)=>upd((x)=>x.radius=v))])),
      Glass(Column(crossAxisAlignment:CrossAxisAlignment.start,children:[const Text('Glass tint'),const SizedBox(height:8),sw(g.tint,(k)=>upd((x)=>x.tint=k)),
        const SizedBox(height:16),const Text('Background glow'),const SizedBox(height:8),sw(g.accent,(k)=>upd((x)=>x.accent=k))])),
      btn('Reset to default',()=>upd((x){final d=GlassCfg();x.blur=d.blur;x.op=d.op;x.border=d.border;x.radius=d.radius;x.tint=d.tint;x.accent=d.accent;}))];}

  @override Widget build(BuildContext c){
    final pages=[signal,forecast,gemini,settings];
    return Scaffold(backgroundColor:const Color(0xFF05070F),extendBody:true,
      body:Stack(children:[Positioned(top:-90,left:-80,child:blob(Color(cfg.value.accent))),Positioned(bottom:100,right:-100,child:blob(const Color(0xFFBF5AF2))),
        SafeArea(child:ListView(padding:const EdgeInsets.fromLTRB(16,8,16,120),children:[const Text('IND AI Trade',style:TextStyle(fontSize:32,fontWeight:FontWeight.w800)),
          const SizedBox(height:12),...pages[t]()]))]),
      bottomNavigationBar:Padding(padding:const EdgeInsets.fromLTRB(20,0,20,20),child:Glass(Row(mainAxisAlignment:MainAxisAlignment.spaceEvenly,children:[
        nav(0,CupertinoIcons.chart_bar_alt_fill,'Signal'),nav(1,CupertinoIcons.clock_fill,'2-Day'),nav(2,CupertinoIcons.bolt_fill,'Gemini'),nav(3,CupertinoIcons.slider_horizontal_3,'Glass')]),p:const EdgeInsets.symmetric(vertical:8))));
  }
}
