# IND AI Trade
1. Upload this folder to a new GitHub repo (or upload the zip contents).
2. Actions tab > "Build IND AI Trade" > Run workflow.
3. Download artifacts: IND-AI-Trade-apk (Android) / IND-AI-Trade-ipa (unsigned iOS; sign via Sideloadly/AltStore).
